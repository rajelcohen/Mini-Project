package geometries;

import java.util.List;
import primitives.*;
import static primitives.Util.*;


/**
 * triangle class represents two-dimensional triangle in 3D Cartesian coordinate
 * system, that is inherited from polygon
 * @author rajel and ruty
 *
 */
public class Triangle extends Polygon
{

	/**
	 * constructor for triangle based on 3 points
	 * @param a
	 * @param b
	 * @param c
	 */
	public Triangle(Point3D a, Point3D b, Point3D c)
	{
		super(a,b,c);
	}

	@Override
	public String toString() {
		return super.toString();
	}
	
	
	//@Override
	//public Vector getNormal(Point3D point)
	//{
		//return super.getNormal(point);
	//}
	
	@Override
	public List<Point3D> findIntersections(Ray ray)
	{

        Point3D _p1 = this.vertices.get(0);
        Point3D _p2 = this.vertices.get(1);
        Point3D _p3 = this.vertices.get(2);

        Vector n = getNormal(_p1);
        Plane plane = new Plane(_p1, n);

        List<Point3D> intersection = plane.findIntersections(ray);

        if (intersection == null)
            return intersection;

        Vector po = new Vector(ray.getP0());
        Vector v1 = new Vector(_p1);
        v1 = po.subtract(v1);
        Vector v2 = new Vector(_p2);
        v2 = po.subtract(v2);
        Vector v3 = new Vector(_p3);
        v3 = po.subtract(v3);

        Vector n1 = v1;
        n1 = n1.crossProduct(v2);
        n1.normalize();
        Vector n2 = v2;
        n2 = n2.crossProduct(v3);
        n2.normalize();
        Vector n3 = v3;
        n3 = n3.crossProduct(v1);
        n3.normalize();

        Vector p = new Vector(intersection.get(0));
        p = po.subtract(p);

        double sign1 = Util.alignZero(p.dotProduct(n1));
        double sign2 = Util.alignZero(p.dotProduct(n2));
        double sign3 = Util.alignZero(p.dotProduct(n3));
        if ((sign1 > 0 && sign2 > 0 && sign3 > 0) || (sign1 < 0 && sign2 < 0 && sign3 < 0))
            return intersection;
        else {
            //intersection.clear();
            intersection = null;
        }

        return intersection;
    
	}
		
	
	
	
	
}



