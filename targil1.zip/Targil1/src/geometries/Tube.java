package geometries;

import java.util.List;
import primitives.*;
import static primitives.Util.*;


/**
 * tube class represents two-dimensional tube in 3D Cartesian coordinate
 * system
 * @author rajel and ruty
 *
 */
public class Tube implements Geometry
{
	Ray axisRay;
	double radius;
	
	/**
	 * constructor of tube based on ray and double
	 * @param axisRay
	 * @param radius
	 */
	public Tube(Ray axisRay, double radius) {
		super();
		this.axisRay = axisRay;
		this.radius = radius;
	}

	/**
	 * 
	 * @return axisRay
	 */
	public Ray getAxisRay() {
		return axisRay;
	}

	/**
	 * 
	 * @return radius
	 */
	public double getRadius() {
		return radius;
	}

	@Override
	public String toString() {
		return "Tube [axisRay=" + axisRay.toString() + ", radius=" + radius + "]";
	}

	@Override
	public Vector getNormal(Point3D p) 
	{
		return null;
	}
	
	
	
	

}
