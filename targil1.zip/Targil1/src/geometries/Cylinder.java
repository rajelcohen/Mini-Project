package geometries;

import java.util.List;
import primitives.*;
import static primitives.Util.*;
public class Cylinder extends Tube 
{
	double hight;

	public Cylinder(Ray axisRay, double radius, double hight) 
	{
		super(axisRay, radius);
		this.hight = hight;
	}

	public double getHight() {
		return hight;
	}

	@Override
	public String toString() {
		return "Cylinder [hight=" + hight + super.toString() + "]";
	}
	

	@Override
	public Vector getNormal(Point3D p) 
	{
		return null;
	}
	
	
	

}
