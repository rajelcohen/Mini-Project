package geometries;

import java.util.List;
import primitives.*;
import static primitives.Util.*;

/**
 *  plane class represents two-dimensional plane in 3D Cartesian coordinate
 * system
 * @author rajel and ruty
 *
 */
public class Plane implements Geometry
{
     final Point3D q0;
     final Vector normal;
	
	/**
	 *  plane constructor based on point3d and vector. 
	 * @param q0
	 * @param normal
	 */
	public Plane(Point3D q0, Vector normal)
	{
		this.q0 = q0;
		this.normal = normal.normalize();
	}
	
	/**
	 * plane constructor based on 3 point3d
	 * @param a
	 * @param b
	 * @param c
	 */
    public Plane(Point3D a, Point3D b, Point3D c)
	{
		q0 = a;
		normal = null;
	}

    /**
     * 
     * @return q0
     */
	public Point3D getQ0() {
		return q0;
	}

	/**
	 * 
	 * @return normal
	 */
	public Vector getNormal() {
		return normal;
	}

	@Override
	public String toString() {
		return "Plane [q0=" + q0.toString() + ", normal=" + normal.toString() + "]";
	}

	@Override
	public Vector getNormal(Point3D p) 
	{
		return null;
	}
	
	
	
	
	
	

	
}
