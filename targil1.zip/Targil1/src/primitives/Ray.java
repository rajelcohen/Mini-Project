package primitives;


/**
 * * Class ray is the basic class representing a ray for Cartesian
 * coordinate system. given the value of the point3d and the direction. The class is based on Util controlling the accuracy.
 * @author rajel and ruty
 *
 */
public class Ray 
{
	Point3D p0;
	Vector dir;
	
	/**
	 * 
	 * @return p0
	 */
	public Point3D getP0() {
		return p0;
	}
	
	/**
	 * 
	 * @param p0 value
	 */
	public void setP0(Point3D p0) 
	{
		this.p0 = p0;
	}
	
	/**
	 * 
	 * @return dir
	 */
	public Vector getDir() {
		return dir;
	}
	
	/**
	 * 
	 * @param dir value
	 */
	public void setDir(Vector dir) {
		this.dir = dir;
	}
	
	/**
	 * 
	 * ray constructor receiving a point3d value and vector value
	 * 
	 * @param p0
	 * @param dir
	 * @throws IllegalArgumentException when value of vector is incorrect
	 */
	public Ray(Point3D p0, Vector dir) throws IllegalArgumentException  
	{
		
		super();
		this.p0 = p0;
		
		this.dir.normalize();
	
		double n = ((dir.head.x.coord * dir.head.x.coord) + (dir.head.y.coord*dir.head.y.coord) + (dir.head.z.coord*dir.head.z.coord)) ;
		if(Math.sqrt(n) == 1) //is normalized
		{
			this.dir = dir;
		}
		else //in need of normalization
		{
			n = Math.sqrt(n);
			Coordinate cx = new Coordinate(dir.head.x.coord/n);
			Coordinate cy = new Coordinate(dir.head.y.coord/n);
			Coordinate cz = new Coordinate(dir.head.z.coord/n);
					
			Point3D p = new Point3D(cx, cy, cz);
			Vector nor = new Vector(p);
			
			this.dir = nor;
		}
		
		
	}
	@Override
	public String toString() {
		return "Ray [p0=" + p0.toString() + ", dir=" + dir.toString() + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Ray other = (Ray) obj;

		return p0.equals(other.p0) && dir.equals(other.dir);
	}
	
	

}
