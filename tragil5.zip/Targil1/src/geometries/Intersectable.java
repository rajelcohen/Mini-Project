package geometries;

import primitives.*;

import java.util.List;
/**
 * interface to make all  others geometries and 3d shapes, connected to have intersections
 * @author rajel and ruth
 *
 */
public interface Intersectable 
{
	
  public List<Point3D> findIntersections(Ray ray);
	
	

}
