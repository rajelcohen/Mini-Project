/**
 * 
 */
package renderer;


import geometries.*;
import primitives.*;

import java.awt.Image;
import java.util.MissingResourceException;

import java.util.List;


import elements.*;
import scene.*;

import scene.Scene;

/**
 * basic - after base class of ray tracer, same as class raytracerbasic but here functions are extended.
 * @author rajel
 *
 */
public class RayTracerBasic extends RayTracerBase {

	/*
	 * raytracerbasic constructor, recieves scene and creates from the base.
	 */
	public RayTracerBasic(Scene s) 
	{
		super(s);
		//return null;
	}
	/*
	 * function that gets all the scene intersections, and finds the closest points colors.
	 * @param ray
	 * @returns scene
	 */
	public Color traceRay(Ray ray)
	{
		List<Point3D> intersections = scene.geometries.findIntersections(ray);
		if(intersections!= null)
		{
			Point3D closestPoint = ray.findClosestPoint(intersections);
			return calcColor(closestPoint);
		}
		
		return scene.background;
	}
	
	/*
	 * function that gets the ambient colors intensity
	 * @param point
	 * @return scene.ambientLight.getIntestity()
	 */
	private Color calcColor(Point3D point)
	{

		return scene.ambientLight.getIntestity();
	}

}
