/**
 * 
 */
package unittests;

import static org.junit.Assert.*;

import org.junit.Test;

import geometries.Cylinder;
import geometries.Tube;
import primitives.Point3D;
import primitives.Ray;
import primitives.Vector;

/**
 * @author rajel and rut
 * * Unit tests for primitives.Cylinder class
 *
 */
public class CylinderTest {

	/**
	 * Test method for {@link geometries.Cylinder#getNormal(primitives.Point3D)}.
	 */
	@Test
	public void testGetNormal() 
	{
		   Ray ray = new Ray(new Point3D(0, 1, 0), new Vector(0, 1, 0));
	        Cylinder cy = new Cylinder(ray, 2, 1);

	        assertEquals(cy.getNormal(new Point3D(0, 0, 0)), new Vector(0, 1, 0));
	   
	}

}
