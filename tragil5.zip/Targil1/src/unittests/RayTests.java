/**
 * 
 */
package unittests;

import java.util.LinkedList;
import java.util.List;

import org.junit.Test;

import primitives.Point3D;
import primitives.Ray;
import primitives.Vector;

import static org.junit.Assert.*;

/**
 * unit test for primitives.ray functions
 * @author rajel
 *
 */
public class RayTests
{
	
/**
 * test function for findClosestPointTest()
 */
	@Test
	public void findClosestPointTest()
	{
		//NB tests:
		//test 1 - second point is the closest
		Ray ray = new Ray(new Point3D(0, 0, 10), new Vector(1,10,-100));
		
		List<Point3D> list = new LinkedList<>();	
		
		list.add(new Point3D(1, 1, -100));
		list.add(new Point3D(-1, 1, -99));
		list.add(new Point3D(0, 2, -10));
		list.add(new Point3D(0.5, 0, -100));
		
		assertEquals("findClosestPoint doesnt work properly", list.get(2), ray.findClosestPoint(list));
	
		 //BVA tests:
	
		//test2 - list is empty
		List<Point3D> list2 = new LinkedList<>();	
		assertNull("findClosestPoint doesnt work properly", ray.findClosestPoint(list2));
		
		//test3 - first point is the one closest
		List<Point3D> list3 = new LinkedList<>();	


		list3.add(new Point3D(-1, 1, -99));
		list3.add(new Point3D(0, 2, -10));
		list3.add(new Point3D(1, 1, -100));
		list3.add(new Point3D(0.5, 0, -100));
		
		assertEquals("findClosestPoint doesnt work properly", list3.get(1), ray.findClosestPoint(list3));
	
		//test4 - last point is the one closest
		List<Point3D> list4 = new LinkedList<>();	

		
		list4.add(new Point3D(1, 1, -100));
		list4.add(new Point3D(0.5, 0, -100));
		list4.add(new Point3D(-1, 1, -99));
		list4.add(new Point3D(0, 2, -10));
		
		assertEquals("findClosestPoint doesnt work properly", list4.get(3), ray.findClosestPoint(list4));
		
	}
	 

}
