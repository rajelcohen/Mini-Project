package elements;
import primitives.*;
import renderer.*;
/**
 * Class ambient light is the basic class representing a light source form all sides, meaning a general light source.
 * it makes all colors of giometries brighter or less brighter.
 * 
 * @author rajel and ruth
 *
 */
public class AmbientLight 
{
	Color intensity; //Ip
	double kA; // kA
	
	
	/*
	 * sets the intensity as the connection of the color and the double recieved
	 */
	public AmbientLight(Color i, double ka) 
	{
		
		intensity = i.scale(ka);
		
	}
	
	/**
	 * 
	 * @return intensity
	 */
	public Color getIntestity() {
		return intensity;
	}
	
	

}
