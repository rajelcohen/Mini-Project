package scene;
import primitives.*;
import elements.*;
import geometries.*;

/**
 * Scene class combines all image neccesities to build one uniformed scene, where the image, geometries, light and shades combine together.
 * 
 * @author rajel and ruth
 */
public class Scene 
{
	String name;
	public Color background = Color.BLACK;
	public AmbientLight ambientLight = new AmbientLight(new Color(192,192,192), 1.d);
	public Geometries geometries = null;
	
	/**
	 * scene constructor
	 * @param name
	 */
	public Scene(String n)
	{
		name = n;
		geometries = new Geometries();
		
	}
	
	/**
	 * sets backround
	 * @param color
	 * @return this
	 */
	public Scene setBackround(Color b)
	{
		background = b;
		return this;
		
	}
	
	/**
	 * sets ambient light
	 * @param ambientlight
	 * @return this
	 */
	public Scene setAmbientLight(AmbientLight a)
	{
		ambientLight = a;
		return this;
	}
	
	/**
	 * 
	 * @param geometries
	 * @return this
	 */
	public Scene setGeometries(Geometries g)
	{
		geometries = g;
		return this;
	}

}
