/**
 * 
 */
package elements;

import primitives.*;
import primitives.Color;
import primitives.Point3D;

/**
 * @author rajel
 *
 */
public class PointLight extends Light implements LightSource
{

	private Point3D position;
	private double kC = 1, kL = 0, kQ = 0;
	
	
	
	/**
	 * @param intensity
	 * @param position
	 * @param kC
	 * @param kL
	 * @param kQ
	 */
	 public PointLight(Color intensity, Point3D p, double kC, double kL, double kQ) {
		super(intensity);
		this.position = p;
		this.kC = kC;
		this.kL = kL;
		this.kQ = kQ;
	}
	 
	 /**
	  * 
	  * @param intensity
	  * @param position
	  */
	 public PointLight(Color intensity, Point3D p) {
		super(intensity);
		this.position = p;
	}
	/**
	 * @param kL the kL to set
	 */
	public PointLight setkL(double kl) {
		this.kL = kl;
		return this;
	}


	/**
	 * @param kQ the kQ to set
	 */
	public PointLight setkQ(double kq) {
		this.kQ = kq;
		return this;
	}

	@Override
	public Color getIntensity(Point3D p) 
	{
		 double d = p.distance(position);
		 double dSquared = p.distanceSqueared(position);
         return getIntensity().scale(1/(this.kC + ( this.kL * d ) + ( this.kQ *dSquared)));
	 
	}

	
	@Override
	public Vector getL(Point3D p) 
	{
		return p.subtract(position).normalized();
	}

	 
	 /**
	  *  double getDistance - Returns the distance between the point and the light source
	  */
	 public double getDistance(Point3D point)
	 {
		 return position.distance(point);
	 }

}
