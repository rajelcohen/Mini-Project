/**
 * 
 */
package elements;

import primitives.*;

import primitives.Color;
import primitives.Point3D;

/**
 * @author rajel
 *
 */
public class DirectionalLight extends Light implements LightSource
{

	private Vector direction;
	
	
	
	/**
	 * @param intensity
	 * @param direction
	 */
	public DirectionalLight(Color intensity, Vector direction) {
		super(intensity);
		this.direction = direction.normalize();
	}

	@Override
	public Color getIntensity(Point3D p) 
	{
		return super.getIntensity();
	}

	@Override
	public Vector getL(Point3D p) 
	{
		return direction.normalize();
	}
	
	public double getDistance(Point3D point)
	 {
		 return Double.POSITIVE_INFINITY;
	 }



}
