package elements;
import primitives.*;
import renderer.*;
/**
 * Class ambient light is the basic class representing a light source form all sides, meaning a general light source.
 * it makes all colors of giometries brighter or less brighter.
 * 
 * @author rajel and ruth
 *
 */
public class AmbientLight extends Light
{
	double kA; // kA

	/**
	 * empty constructor
	 */
	public AmbientLight()
	{
		super(Color.BLACK);
	}
	
	/**
	 * sets the intensity as the connection of the color and the double recieved
	 * @param i
	 * @param _Ka
	 */
	public AmbientLight(Color i, double ka) 
	{
		//super(i.scale(ka));
		
		super(new Color(i.getColor().getRed()*ka,i.getColor().getGreen()*ka,i.getColor().getBlue()*ka));		//super(_Ia.)
	
	}
	
	
	

}
