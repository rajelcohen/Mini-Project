/**
 * 
 */
package unittests;
import primitives.*;
import geometries.Plane;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;



/**
 * @author rajel and ruth
 *  * Unit tests for Geometries.Plane class
 *
 */
public class PlaneTest
{

	/**
	 * Test method for {@link geometries.Plane#getNormal(primitives.Point3D)}.
	 */
	@Test
	public void testGetNormalPoint3D() 
	{
		
		  Point3D p1 = new Point3D(1, 1, 1);
	      Point3D p2 = new Point3D(3, 3, 2);
	      Point3D p3 = new Point3D(6, 6, 6);
	      Plane pl = new Plane(p1, p2, p3);
	      Vector n = pl.getNormal();
	      Vector s = new Vector(5, -5, 0);
	      s.normalize();
	      assertEquals(s, n);	
		
		
	}
	
	/**
	 * Test method for {@link geometries.Plane#findIntersections(primitives.Point3D)}.
	 */
	public void testFindIntersections() 
	{
		Plane plane = new Plane(new Point3D(0, 0, 2), new Point3D(0, -1, 0), new Point3D(0, -3, 0));
		
	//EP tests -  neither orthogonal nor parallel to the plane

	//test1 - ray intersects the plane (1)
		List<Point3D> result = plane.findIntersections(new Ray(new Point3D(2, 0, 0),new Vector(-2, 0, 2)));
        assertEquals("Wrong number of points", 1, result.size());
	
		
	//test2 - ray doesn't intersect (0)
       assertNull("Ray's line out of plane", plane.findIntersections(new Ray(new Point3D(-3, 0, 0), new Vector(-2.17, -1.57, 0))));
   
	//BVA - 7 cases	
		
	//test3 - ray parallel to plane (0)
       
       assertNull("Ray's line out of plane", plane.findIntersections(new Ray(new Point3D(-2, 0, 0), new Vector(1, 0, 0))));
		
	//test4 - ray included in ray (0)
       
       assertNull("Ray's line out of plane", plane.findIntersections(new Ray(new Point3D(0, -3, 0), new Vector(0, -0.24, 4.68))));
		
	//test5 - ray not included in ray (0)
       
       assertNull("Ray's line out of plane", plane.findIntersections(new Ray(new Point3D(-1, 0, 0), new Vector(-1.19, 2.05, 0))));
		
	//orthogonal tests
		
	//test6 - P0 before plane (1)
       List<Point3D> result1 = plane.findIntersections(new Ray(new Point3D(-1, 0, 0),new Vector(0, 1, 0)));
       assertEquals("Wrong number of points", 1, result1.size());
	
	//test7 - P0 in plane (0)
       assertNull("Ray's line out of plane", plane.findIntersections(new Ray(new Point3D(0, -1, 0), new Vector(0, -1, 0))));
	
	//test8 - p0 after plane (0)
       
       assertNull("Ray's line out of plane", plane.findIntersections(new Ray(new Point3D(1.27, -1, 0), new Vector(0, -1, 0))));
   	
	//test 9 - ray begins at ray
		

       assertNull("Ray's line out of plane", plane.findIntersections(new Ray(new Point3D(0, 0, 2), new Vector(-4, 4, -2))));
       
	//test10 - ray starts at the reference point of plane - Q	
		
       assertNull("Ray's line out of plane", plane.findIntersections(new Ray(new Point3D(0, 0, 2), new Vector(-3.34, 2.09, -2))));
       
		
		
		
		
		
	}

}
