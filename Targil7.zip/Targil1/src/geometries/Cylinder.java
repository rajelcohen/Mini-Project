package geometries;

import java.util.List;
import primitives.*;
import static primitives.Util.*;
public class Cylinder extends Tube 
{
	double hight;

	public Cylinder(Ray axisRay, double radius, double hight) 
	{
		super(axisRay, radius);
		this.hight = hight;
	}

	public double getHight() {
		return hight;
	}

	@Override
	public String toString() {
		return "Cylinder [hight=" + hight + super.toString() + "]";
	}
	

	@Override
	public Vector getNormal(Point3D p) 
	{
		//check where the point is, sides, or lids:

		Point3D P0 = axisRay.getP0();
		Vector P0_P = p.subtract(P0);
		double x = P0_P.length();
		if(x >= radius) // just like the tube
		{
			return super.getNormal(p);
		}
		
		else // point is at one of the lids
		{
			Vector v = axisRay.getDir();
			return v.normalize();
		}
		
		
	}
	
	
	@Override
	public List<Point3D> findIntersections(Ray ray) {
		// TODO Auto-generated method stub
		return null;
	
	}

}
