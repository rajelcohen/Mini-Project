package geometries;

import java.util.LinkedList;
import java.util.List;

import primitives.Point3D;
import primitives.Ray;

public class Geometries implements Intersectable 
{
	
	 List <Intersectable> intersectables;

	 
	   public Geometries() {
	       intersectables = new LinkedList<>();
	    }

	    public void add (Intersectable... intersectables)
	    {
	        for (Intersectable item : intersectables)
	            this.intersectables.add(item);

	    }

	    public Geometries(Intersectable... intersectables ) {
	       this.intersectables= new LinkedList<>();
	       add(intersectables);
	    }

	  

		@Override
		public List<GeoPoint> findGeoIntersections(Ray ray) 
		{
			  List<GeoPoint> result = null;

		       for (Intersectable item : this.intersectables ) {
		           List <GeoPoint> itemPoints = item.findGeoIntersections(ray);
		           if(itemPoints!= null){
		               if (result == null){
		                   result = new LinkedList<>();
		               }
		               result.addAll(itemPoints);
		           }


		       }

		       return result;
			
		}

}
