package geometries;

import java.util.List;
import primitives.*;

import static primitives.Point3D.ZERO;
import static primitives.Util.*;

/**
 *  plane class represents two-dimensional plane in 3D Cartesian coordinate
 * system
 * @author rajel and ruty
 *
 */
public class Plane extends Geometry
{
      Point3D q0;
      Vector normal;
	
	/**
	 *  plane constructor based on point3d and vector. 
	 * @param q0
	 * @param normal
	 */
	public Plane(Point3D q0, Vector normal)
	{
		this.q0 = q0;
		this.normal = normal.normalize();
	}
	
	/**
	 * plane constructor based on 3 point3d
	 * @param a
	 * @param b
	 * @param c
	 */
    public Plane(Point3D a, Point3D b, Point3D c)
	{

		q0 = a;
    	Vector v1 = a.subtract(b);
    	Vector v2 = b.subtract(c);
    	
    	Vector n = v1.crossProduct(v2);
    	normal = n.normalize();
    	
    	
	}

    /**
     * 
     * @return q0
     */
	public Point3D getQ0() {
		return q0;
	} 

	/**
	 * 
	 * @return normal
	 */
	public Vector getNormal() {
		return normal;
	}

	@Override
	public String toString() {
		return "Plane [q0=" + q0.toString() + ", normal=" + normal.toString() + "]";
	}

	@Override
	public Vector getNormal(Point3D p) 
	{
		return normal;
	}


	@Override
	public List<GeoPoint> findGeoIntersections(Ray ray) { 
		Point3D P0 = ray.getP0();
		Vector v = ray.getDir();
		
		Vector n = normal;
		
		Vector P0_Q0 = P0.subtract(q0);
		double mechane = alignZero(n.dotProduct(P0_Q0));
		
		if(isZero(mechane))
		{
			return null;
		}
		
		double nv = alignZero(n.dotProduct(v));
		
		if(isZero(nv))
		{
			return null;
		}
		
		double t = alignZero(mechane/nv);
		
		Point3D P = ray.getPoint(t);
		//Point3D P = P0.add(v.scale(t));
		
		return List.of(new GeoPoint(this, P));
		
		
		
	}
	
	
	
	
	
	
	

	
}
