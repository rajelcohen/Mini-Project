
/**
 * 
 */
package renderer;
import java.lang.Math;

import static primitives.Point3D.ZERO;
import static primitives.Util.alignZero;
import static primitives.Util.isZero;

import geometries.*;
import geometries.Intersectable;
import primitives.*;
import geometries.Intersectable.GeoPoint;
import java.awt.Image;
import java.util.MissingResourceException;

import java.util.List;

import geometries.Intersectable.GeoPoint;
import elements.*;
import scene.*;

import scene.Scene;

/**
 * basic - after base class of ray tracer, same as class raytracerbasic but here scene is present.
 * @author rajel
 * @return true if the point unshaded or false if the point shaded
 * */
public class RayTracerBasic extends RayTracerBase 
{

	private static final double INITIAL_K = 1.0;
	private static final double DELTA = 0.1;
	private static final int MAX_CALC_COLOR_LEVEL = 10;
	private static final double MIN_CALC_COLOR_K = 0.001;
	
	
	
	/**
	 * raytracerbasic constructor, recieves scene and creates from the base.
	 * @param s
	 */
	public RayTracerBasic(Scene s) 
	{
		super(s);
		//return null;
	}
	
	/**
	 * 
	 * 
	 * @param l
	 * @param n
	 * @param gp
	 * @return true if the point unshaded or false if the point shaded
	 */
	private boolean unshaded( LightSource light, Vector l, Vector n, GeoPoint geopoint)
	 {
		Vector lightDirection = l.scale(-1); // from point to light source
		Vector delta = n.scale(n.dotProduct(lightDirection) > 0 ? DELTA : - DELTA);
		Point3D point = geopoint.point.add(delta);
		Ray lightRay = new Ray(point, lightDirection);
		List<GeoPoint> intersections = scene.geometries.findGeoIntersections(lightRay);
		if (intersections == null) return true;
		double lightDistance = light.getDistance(geopoint.point);
		for (GeoPoint gp : intersections) 
		{
			if (alignZero(gp.point.distance(geopoint.point) - lightDistance) <= 0
				&& geopoint.geometry.getMaterial().kT == 0)
			return false;
		}
		return true;
	}
	
	
	/**
	 * 
	 * @param lightSource
	 * @param intersection
	 * @return
	 */
//	private boolean unshaded(LightSource lightSource, GeoPoint intersection)
//	{
//		Vector lightDirectional = lightSource.getL(intersection.point).scale(-1).normalize();
//		Ray lightRay = new Ray(intersection, lightDirectional, DELTA);
//		List<GeoPoint> i = scene.geometries.findGeoIntersections(lightRay);
//		return i == null;
//		
//	}

	
	
	/**
	 * A function that returns a reflection of bodies that have partial shading
	 * @param light
	 * @param l
	 * @param n
	 * @param geopoint
	 * @return double 
	 */
	private double transparency(LightSource light, Vector l, Vector n, GeoPoint geopoint) {
		Vector lightDirection = l.scale(-1); // from point to light source
		Ray lightRay = new Ray(geopoint.point, lightDirection, n);
		double lightDistance = light.getDistance(geopoint.point);
		var intersections = scene.geometries.findGeoIntersections(lightRay);
		if (intersections == null)
			return 1.0;
		double ktr = 1.0;
		for (GeoPoint gp : intersections) {
			
			if (alignZero(gp.point.distance(geopoint.point) - lightDistance) <= 0) {
				ktr *= gp.geometry.getMaterial().kT;
				if (ktr < MIN_CALC_COLOR_K)
					return 0.0;
			}
		}
		return ktr;
	}
	

	

	/**
	 * function that gets all the scene intersections, and finds the closest points colors.
	 * @param ray
	 * @returns scene
	 */
	
	public Color traceRay(Ray ray) {
		var intersections = scene.geometries.findGeoIntersections(ray);
		if (intersections == null || intersections.isEmpty())
			return scene.background;
		GeoPoint closestPoint = ray.findClosestGeoPoint(intersections);
		return closestPoint == null ? Color.BLACK : calcColor(closestPoint, ray);
		
//		GeoPoint closestPoint = findClosestIntersection(ray);	
//		return closestPoint == null ? scene.background : calcColor(closestPoint, ray);

	}
	
	
	/**
	 * 
	 * @param intersection
	 * @param ray
	 * @param level
	 * @param k
	 * @return
	 */
	private Color calcColor(GeoPoint intersection, Ray ray, int level, double k)
	{
		
		Color color = intersection.geometry.getEmmission();
		//color = color.add(callocalEffects(intersection, ray));
		for (LightSource lightSource : scene.light) {
			Vector l = lightSource.getL(intersection.point);
			Vector n = intersection.geometry.getNormal(intersection.point);
			if (n.dotProduct(l) * n.dotProduct(ray.getDir()) > 0) {
				double ktr = transparency(lightSource, l, n, intersection);
				if (ktr * k > MIN_CALC_COLOR_K) {
					Color lightIntensity = lightSource.getIntensity(intersection.point).scale(ktr);
					color = color.add(calcDiffusive(intersection.geometry.getMaterial(), l, n, lightIntensity),
							calcSpecular(intersection.geometry.getMaterial(), l, n, ray.getDir(),
									intersection.geometry.getMaterial().nShininess, lightIntensity));
				}
			}
		}
		
		return 1 == level ? color: color.add(calcGlobalEffects(intersection, ray, level, k)) ;
		
	}

	/**
	 * A function that receives a dot parameter and returns color
	 * 
	 * @param geoPoint
	 * @return color
	 */
	private Color calcColor(GeoPoint intersection, Ray ray) {
//		return scene.ambientLight.getIntensity().add(intersection.geometry.getEmmission())
//				.add(callocalEffects(intersection, ray));
		
		return calcColor(intersection,ray,MAX_CALC_COLOR_LEVEL,INITIAL_K).add(scene.ambientLight.getIntensity());
		

	}
//	
	
	

	/**
	 * 
	 * @param intersection
	 * @param ray
	 * @return
	 */
	private Color callocalEffects(GeoPoint intersection, Ray ray)
	{
		Vector v = ray.getDir().normalize(); // Vector from camera to body
		Vector n = intersection.geometry.getNormal(intersection.point).normalize();
		Material m = intersection.geometry.getMaterial();
		//n.normalize();
		double nv = Util.alignZero(n.dotProduct(v));
		if (nv == 0)
			return Color.BLACK;
		int nShininess = intersection.geometry.getMaterial().nShininess;
		double kd = intersection.geometry.getMaterial().kD;
		double ks = intersection.geometry.getMaterial().kS;
		Color color = Color.BLACK;
		for (elements.LightSource lightSource : scene.light) 
		{
			Vector l = lightSource.getL(intersection.point).normalize(); // Vector from the light source to the point
			//l.normalize();
			double nl = Util.alignZero(n.dotProduct(l));
			if (nl * nv > 0) // If the camera and light source are not in opposite directions (sign(nl) ==sing(nv)
			{
				if(unshaded(lightSource, l, n, intersection))
				{
					Color lightIntensity = lightSource.getIntensity(intersection.point); // The intensity of the light source at a certain point
				    color = color.add(calcDiffusive(m, l, n, lightIntensity),calcSpecular(m, l, n, v, nShininess, lightIntensity));
				}
			
			}
			
		}
		// System.out.println(color);

		return color;
	}
	
	/**
	 * 
	 * @param intersection
	 * @param ray
	 * @param level
	 * @param k
	 * @return
	 */
	private Color calcGlobalEffects(GeoPoint geopoint, Ray ray, int level, double k) 
	{
		Color color = Color.BLACK;
		Material material = geopoint.geometry.getMaterial();
		double kr = material.kR, kkr = k * kr;
		if (kkr > MIN_CALC_COLOR_K) 
		{
			Ray reflectedRay = constructReflectedRay(geopoint.geometry.getNormal(geopoint.point), geopoint.point, ray);
			GeoPoint reflectedPoint = findClosestIntersection(reflectedRay);
			if (reflectedPoint == null)
			return color;
			color = color.add(calcColor(reflectedPoint, reflectedRay, level - 1, kkr).scale(kr));
	
		}
		
		double kt = material.kT, kkt = k * kt;
		if (kkt > MIN_CALC_COLOR_K) {
			Ray refractedRay = constructRefractedRay(geopoint.geometry.getNormal(geopoint.point), geopoint.point, ray);
			GeoPoint refractedPoint = findClosestIntersection(refractedRay);
			if (refractedPoint == null)
				return color;
			color = color.add(calcColor(refractedPoint, refractedRay, level - 1, kkt).scale(kt));
		}
		return color;
		
		}
		

		
		
	
	
//	/**
//	 * 
//	 * @param ray
//	 * @param level
//	 * @param kx
//	 * @param kkx
//	 * @return
//	 */
//	private Color calcGlobalEffects(Ray ray, int level, double kx, double kkx)
//	{
//		GeoPoint gp = findClosestIntersection(ray);
//		return (gp == null ? scene.background : calcColor(gp, ray, level-1,kkx)).scale(kx);
//	}


	private GeoPoint findClosestIntersection(Ray ray) 
	{
		List<GeoPoint> listOfGeoPoints = scene.geometries.findGeoIntersections(ray);
//		return ray.findClosestGeoPoint(pointList);
//			List<GeoPoint> listOfGeoPoints = scene.geometries.findGeoIntersections(ray); // Calculate all the intersections of the fund with all the entities it passes through
		if (listOfGeoPoints == null) // if there are no intersection
			return null;
		if (listOfGeoPoints.isEmpty()) // if there are no intersection
			return null;

		return ray.findClosestGeoPoint(listOfGeoPoints); // closest GoePoint to the head of the ray

	}

	/**
	 * Calculation of a reflection ray
	 * 
	 * @param n
	 * @param point
	 * @param inRay
	 * @return reflection ray
	 */
	private Ray constructReflectedRay(Vector n, Point3D point, Ray inRay) {
		// Vector delta = n.scale(DELTA);
		// Point3D new_point = point.add(delta);
		double vn = inRay.getDir().dotProduct(n); // v * n
		double vn2 = vn * 2;
		Vector vec = n.scale(vn2);
		return new Ray(point, vec.subtract(inRay.getDir()), n);
		// return new Ray (new_point,vec.subtract(inRay.getDir()));
	}

	/**
	 * Calculation of a refracted ray
	 * @param n
	 * @param point
	 * @param inRay
	 * @return refracted ray
	 */
	private Ray constructRefractedRay(Vector n, Point3D point, Ray inRay) {
		// Vector delta = n.scale(- DELTA);
		// Point3D new_point = point.add(delta);

		return new Ray(point, inRay.getDir(), n);
	}

	
	/**
	 * 
	 * @param material
	 * @param l
	 * @param n
	 * @param v
	 * @param nShininess
	 * @param lightIntensity
	 * @return
	 */
	private Color calcSpecular(Material material, Vector l, Vector n, Vector v, int nShininess, Color lightIntensity)
	{
	// NEXT TWO LINES ARE MINE
  	double ks= material.kS;
	Vector lnn2 = n.scale(2 * l.dotProduct(n));
	Vector r = lnn2.subtract(l); // Calculating reflectance vector ( r = l - 2* (l*n)*n)
	// r.normalize();
	double vr = (v.dotProduct(r)) * -1; // -v * r
	double max = Math.max(0, vr);
	double num = Math.pow(max, nShininess);
	return lightIntensity.scale(ks * num);

	}
	
	/**
	 * 
	 * @param material
	 * @param l
	 * @param n
	 * @param lightIntensity
	 * @return
	 */
	private Color calcDiffusive(Material material, Vector l, Vector n, Color lightIntensity) 
	{
		double kd = material.kD;
		double nl = n.dotProduct(l);
		return lightIntensity.scale(kd * Math.abs(nl));
	}

}

 