/**
 * 
 */
package unittests;

import static org.junit.Assert.*;
import geometries.Tube;
import primitives.Point3D;
import primitives.Ray;
import primitives.Vector;


import org.junit.Test;

/**
 * @author rajel and rut
 * * Unit tests for primitives.Tube class
 *
 */
public class TubeTest {

	/**
	 * Test method for {@link geometries.Tube#getNormal(primitives.Point3D)}.
	 */
	@Test
	public void testGetNormal() 
	{

		//EP
        Ray ray = new Ray(new Point3D(0, 1, 0), new Vector(0, 1, 0));
        Tube tb = new Tube(ray,2);

        assertEquals(tb.getNormal(new Point3D(0, 0, 0)), new Vector(0, -1, 0));
        
        //BVA
        
        Ray ray2 = new Ray(new Point3D(0, 1, 0), new Vector(0, 0, 1));
        Tube tb2 = new Tube(ray2,2);

        assertEquals(tb2.getNormal(new Point3D(0, 0, 0)), new Vector(0, -1, 0));
        
	}

	
	
	
}
