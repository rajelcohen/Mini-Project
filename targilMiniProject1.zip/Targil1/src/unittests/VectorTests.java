/**
 * 
 */
package unittests;
import primitives.*;

import static java.lang.System.out;
import static org.junit.Assert.*;
import static primitives.Util.isZero;

import org.junit.Test;

/**
 * @author rajel and ruth
 *  * Unit tests for primitives.Vector class
 *
 */
public class VectorTests 
{
	/**
     * Test method for {@link primitives.Vector#crossProduct(primitives.Vector)}.
     */

	//3 vectors to help us during the tests
	 Vector v1 = new Vector(1, 2, 3);
	 Vector v2 = new Vector(-2, -4, -6);
	 Vector v = new Vector(1, 2, 3);
	 Vector v3 = new Vector(0, 3, -2);

	/**
	  * Test method for {primitives.Util.isZero}.
	 */
	@Test
	public void testZeroPoint()
	{
	  assertThrows("Error zero()", IllegalArgumentException.class, ()->new Vector(0,0,0));
	}
	
	/**
	 * Test method for {@link primitives.Vector#add(primitives.Vector)}.
	 */
	@Test
	public void testAdd() 
	{
		Vector v = v1.add(v2);
		Vector v4 = new Vector(-1,-2,-3);
		assertEquals("Add() wrong result",v,v4);
	}

	/**
	 * Test method for {@link primitives.Vector#subtract(primitives.Vector)}.
	 */
	@Test
	public void testSubtract() 
	{
		Vector f = v1.subtract(v2);
		Vector v4 = new Vector(-3,-6,-9);
		assertEquals("Subtract() wrong result",v4,f);
	}

	/**
	 * Test method for {@link primitives.Vector#scale(double)}.
	 */
	@Test
	public void testScale() 
	{
		 Vector vscale = v1.scale(-0.999999);
	     assertEquals("Scale() wrong result",v1.length(), vscale.length(), 0.0001);
	}

	/**
	 * Test method for {@link primitives.Vector#crossProduct(primitives.Vector)}.
	 */
	@Test
	public void testCrossProduct() 
	{
		
        Vector v1 = new Vector(1, 2, 3);

        // ============ Equivalence Partitions Tests ==============
        Vector v2 = new Vector(0, 3, -2);
        Vector vr = v1.crossProduct(v2);

        // TC01: Test that length of cross-product is proper (orthogonal vectors taken
        // for simplicity)
        assertEquals("crossProduct() wrong result length", v1.length() * v2.length(), vr.length(), 0.00001);

        // TC02: Test cross-product result orthogonality to its operands
        assertTrue("crossProduct() result is not orthogonal to 1st operand", Util.isZero(vr.dotProduct(v1)));
        assertTrue("crossProduct() result is not orthogonal to 2nd operand", Util.isZero(vr.dotProduct(v2)));

        // =============== Boundary Values Tests ==================
        // TC11: test zero vector from cross-productof co-lined vectors
        Vector v3 = new Vector(-2, -4, -6);
        assertThrows("crossProduct() for parallel vectors does not throw an exception",
                IllegalArgumentException.class, () -> v1.crossProduct(v3));
        // try {
        //     v1.crossProduct(v2);
        //     fail("crossProduct() for parallel vectors does not throw an exception");
        // } catch (Exception e) {}

	}

	/**
	 * Test method for {@link primitives.Vector#dotProduct(primitives.Vector)}.
	 */
	@Test
	public void testDotProduct() 
	{
		
	   assertTrue("ERROR: dotProduct() for orthogonal vectors is not zero",isZero(v1.dotProduct(v3)));
	   assertTrue("ERROR: dotProduct() wrong value",isZero(v1.dotProduct(v2) + 28));

	}

	/**
	 * Test method for {@link primitives.Vector#lengthSquared()}.
	 */
	@Test
	public void testLengthSquared() 
	{
		  assertTrue("ERROR: lengthSquared() wrong value",isZero(v1.lengthSquared() - 14));
	      
	}

	/**
	 * Test method for {@link primitives.Vector#length()}.
	 */
	@Test
	public void testLength() 
	{
	   
	     Vector vCopy = new Vector(v.getHead());
	     Vector vCopyNormalize = vCopy.normalize();
	     assertTrue("ERROR: length() wrong value",isZero(vCopyNormalize.length() - 1));
	}

	/**
	 * Test method for {@link primitives.Vector#normalize()}.
	 */
	@Test
	public void testNormalize() 
	{
        Vector vCopy = new Vector(v.getHead());
        Vector vCopyNormalize = vCopy.normalize();
        assertEquals("ERROR: normalize() function creates a new vector",vCopy,vCopyNormalize);

      }

	/**
	 * Test method for {@link primitives.Vector#normalized()}.
	 */
	@Test
	public void testNormalized() 
	{
		Vector u = v.normalized();
		assertEquals("Error: normalized() function does not create a new vector",u, v);
		}

}
