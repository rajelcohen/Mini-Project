package renderer;

import java.util.Random;
import elements.DirectionalLight;
import elements.LightSource;
import elements.PointLight;
import geometries.Intersectable.GeoPoint;
import primitives.*;

import scene.Scene;

public class RayTracerSoftShadows extends RayTracerBasic
{
	public RayTracerSoftShadows(Scene s) 
	{
		super(s);
	}

	public double calcSoftShadows(Point3D point, GeoPoint intersection,LightSource lightSource, Vector n, int amountofrayssent, int radiusOfLight) 
	{
		Point3D center1 = lightSource.getL(new Point3D(0, 0, 0)).getHead();
		//Point3D center1 = lightSource.getPosition();
		if(lightSource instanceof DirectionalLight) // we only do the calcsoftShadows in spot/point light
			radiusOfLight = 0;
		
			int count = 0;
			double transparencyofall = 0;
			while(count != amountofrayssent)
			{
				int max = 1, min = -1;
				//test - send random ray
				//size of "sphere around central point of light
				Coordinate x = new Coordinate ((new Random().nextInt(max - min + 1) + min) * radiusOfLight); //((double) ((Math.random() * (1 - (-1))) + (-1)) * radiusOfLight);
				Coordinate y = new Coordinate ((new Random().nextInt(max - min + 1) + min) * radiusOfLight);//((double) ((Math.random() * (1 - (-1))) + (-1)) * radiusOfLight);
			
				//random point in sphere from where we throw a ray
				Point3D p = new Point3D(x.operatormult(center1.getX()), y.operatormult(center1.getY()), center1.getZ());
					
				Vector l = point.subtract(p).normalized();
				//Vector l = p.subtract(point).normalized();
				n = intersection.geometry.getNormal(point);
				
				transparencyofall = transparencyofall + transparency(lightSource,l , n, intersection);

				count++;
			}

			transparencyofall = transparencyofall/amountofrayssent;
			
			return transparencyofall;

		
		
	}
	
	

}
