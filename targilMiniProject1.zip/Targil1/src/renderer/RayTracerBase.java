/**

 * 
 */
package renderer;

import geometries.*;
import primitives.*;
import elements.*;
import scene.*;


/**
 * base class of ray tracing, meaning taking the ray received and receiving all info on the shapes it went trough
 * @author rajel and ruth
 *
 */
public abstract class RayTracerBase 
{
	/**
	 * protected field showing the scene in view plane
	 */
	protected Scene scene;
	protected int radiusOfLight;
	protected int amountofrayssent;
	
	/*
	 * creating a raytracer where scene is the one recieved
	 */
	public RayTracerBase(Scene s)
	{
		scene = s;

	}
	
	
	
	/**
	 * a public abstract method traceRay that receives a beam in the parameter and
	 * returns Color
	 * 
	 * @param _ray
	 * @return Color
	 */
	public abstract Color traceRay(Ray r);
}
