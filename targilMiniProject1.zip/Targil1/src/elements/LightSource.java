/**
 * 
 */
package elements;

import primitives.*;
import primitives.Color;
import primitives.Point3D;

/** base interface for all type of light, spot, point, directional, and ambient...
 * @author rajel and ruth
 *
 *
 */
public interface LightSource 
{
	
	/**
	 * all type of lights need intensity showing how bright the light is, meaning how sharp the colors are showed
	 * @param p
	 * @return Color
	 */
	public Color getIntensity(Point3D p);
	
	/**
	 * function to get exact location of light, normalization of vector in all type of lights
	 * @param p
	 * @return vector
	 */
	public Vector getL(Point3D p);
	
	/**
	 * distance of light, how far it goes, that is why ambient for example always is showed as infinite.
	 * @param point
	 * @return double
	 */
	public double getDistance(Point3D point);
	
	public Point3D getPosition();

}
