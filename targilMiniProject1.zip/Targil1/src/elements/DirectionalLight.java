/**
 * 
 */
package elements;

import primitives.*;

import primitives.Color;
import primitives.Point3D;

/**
 * * Class directional light is the basic class representing a light source from a direct place going straight, to one direct hit, meaning a specific light source.
 * 
 * @author rajel and ruth
 *
 */
public class DirectionalLight extends Light implements LightSource
{

	/**
	 * directional light needs a vector showing in what direction its going.
	 */
	private Vector direction;
	
	
	
	/**
	 * basic constructor, showing at what intensity of light and in which direction its going.
	 * @param intensity
	 * @param direction
	 */
	public DirectionalLight(Color intensity, Vector direction) {
		super(intensity);
		this.direction = direction.normalize();
	}

	@Override
	public Color getIntensity(Point3D p) 
	{
		return super.getIntensity();
	}

	@Override
	public Vector getL(Point3D p) 
	{
		return direction.normalize();
	}
	
	/**
	 * function to get distance of point
	 * @param point
	 * @return positive infinity of point
	 */
	public double getDistance(Point3D point)
	 {
		 return Double.POSITIVE_INFINITY;
	 }

	@Override
	public Point3D getPosition() {
		return new Point3D(0, 0, 0);
	}



}
