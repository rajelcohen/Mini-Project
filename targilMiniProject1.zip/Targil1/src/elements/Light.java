package elements;

import primitives.Color;
import primitives.Point3D;

/**
 * base class for all type of light, spot, point, directional, and ambient...
 * @author rajel and ruth
 *
 */
public abstract class Light 
{
	private Color intensity;

	/**
	 * constructor of Light
	 * @param intensity
	 */
	protected Light(Color intensity) {
		this.intensity = intensity;
	}

	/**
	 * function to get intensity
	 * @return the intensity
	 */
	public Color getIntensity() {
		return intensity;
	}

	
	
	
	

}
