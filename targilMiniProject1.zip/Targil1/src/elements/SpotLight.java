/**
 * 
 */
package elements;

import primitives.Color;
import primitives.Point3D;
import primitives.Vector;


import static primitives.Util.isZero;
import primitives.*;
import geometries.*;


import static primitives.Point3D.ZERO;
import static primitives.Util.alignZero;
import static primitives.Util.isZero;



/**
 * Class Spot light is the class representing a light source form a certain point, meaning a specific light source.
 * it makes all colors of point making a splash of white in certain points
 * 
 * @author rajel and ruth
 *
 */
public class SpotLight extends PointLight 
{
	//direction of light
	private Vector direction;
	

	/**
	 * basic constructor for spotLighr]t
	 * @param intensity
	 * @param position
	 * @param d
	 */
	public SpotLight(Color intensity, Point3D position, Vector d)
	{
		super(intensity, position);
		this.direction = d.normalized();
		// TODO Auto-generated constructor stub
	}
	
	
	@Override
	public Color getIntensity(Point3D p) 
	{
		//function for spot light is:
		//intensity = (intensity*max(0,direction*intensity))/(KC + KL* direction + KQ * direction^2)
		 double dirl =  this.direction.dotProduct(getL(p));
		 double max = Math.max(0, dirl);
		 return super.getIntensity(p).scale(max);
	}
	
	
	/**
	 * set KL
	 * @param _kL
	 * @return
	 */
	 public SpotLight setKl(double _kL)
	 {
		 super.setkL(_kL);
		 return this;
	 }
	 
	 /** Kq
	  * set 
	  * @param _Kq
	  * @return
	  */
	 public SpotLight setKq(double _Kq)
	 {
		 super.setkQ(_Kq);
		 return this;
	 }
	

}
