/**
 * 
 */
package elements;

import static primitives.Util.isZero;
import primitives.*;
import geometries.*;


/**
 * Class camera is the basic class representing a camera for 3D perspective. 
 * The class is based on Util, Geometries and Primitives. It is the point of view from the view plane to the geometries
 * @author rajel and ruth
 *
 */
public class Camera 
{
	/**
	 * Camera uses a point, where it stands.
	 * 3 vectors showing the exact location, and where camera is facing.
	 * distance to show how far from view plane it stands
	 */
    Point3D p0;
    Vector vUp;
	Vector vTo;
    Vector vRight;
	double width;
	double hight;
	double distance;
	int p1;
	
	/**
	 * function to get P0
	 * @return p0
	 */
	public Point3D getP0() {
		return p0;
	}
	
	/**function to get P0
	 * 
	 * @return vUp
	 */
	public Vector getvUp() {
		return vUp;
	}
	
	/**
	 * function to get VTO
	 * @return vTo
	 */
	public Vector getvTo() {
		return vTo;
	}
	
	
	/**
	 * function to get VRIGHT
	 * @return vRright
	 */
	public Vector getvRight() {
		return vRight;
	}
	
	/**
	 * function to get WIDTH
	 * @return width
	 */
	public double getWidth() {
		return width;
	}
	
	/**
	 * function to get HIGHT
	 * @return hight
	 */
	public double getHight() {
		return hight;
	}
	
	/**
	 * function to get DISTANCE
	 * @return distance
	 */
	public double getDistance() {
		return distance;
	}
	
	
	/**
	 * function for creation oc camera, recieves point vector to and vector up, creates vector right.
	 * @param o
	 * @param to
	 * @param up
	 */
	public Camera(Point3D o, Vector to, Vector up)
	{
		if(!isZero(up.dotProduct(to))) // no vectors can be dot product of zero, they all have to be orthogonal
		{
			throw new IllegalArgumentException("vTo and vUp are not orthogonal");	
		}
		
		//make sure they are normalized
		p0 = o;
		vTo = to.normalize();
		vUp = up.normalize();
		
		
		vRight = vTo.crossProduct(vUp);
		
	}
	
	/**
	 * creation to set view plane, receives width and HIGHT, and sets them
	 * @param w
	 * @param h
	 * @return
	 */
	public Camera setViewPlaneSize(double w, double h)
	{
		if(w == 0 || h == 0) //neither can be 0
		{
			throw new IllegalArgumentException("the width or hight of the veiw plane can't be 0");	
		}
		
		width = w;
		hight = h;
		return this;
		
	} 
	
	/**
	 * function to set distance, gets distance and returns the camera
	 * @param d 
	 * @return
	 */
	public Camera setDistance(double d)
	{
		distance = d;
		return this;
	}
	
	/**
	 * function to calculate the ray that would pass through specific pixel in view plane of this camera, returns the ray.
	 * @param nX = size of x in view plane
	 * @param nY = size of y in view plane
	 * @param j = amount of pixels in x
	 * @param i = amount of pixels in y
	 * @return
	 */
	public Ray constructRayThroughPixel(int nX, int nY, int j, int i)
	{
		//image center
		Point3D Pc = p0.add(vTo.scale(distance));
		
		//ratio
		double Ry = hight/nY;
		double Rx = width/nX;
		
		//pixel center
		Point3D Pij = Pc;
		double Yi = -(i - (nY - 1)/2d)*Ry; 
		double Xj = (j - (nX -1)/2d)*Rx;
		
		if(!isZero(Xj))
		{
			Pij = Pij.add(vRight.scale(Xj));			
		}
		
		if(!isZero(Yi))
		{
			Pij = Pij.add(vUp.scale(Yi));
		}
		
		Vector Vij = Pij.subtract(p0);
		
		
		return new Ray(p0,Vij.normalize());
			
	}

	
	
	

}
