/**
 * 
 */
package elements;

import primitives.*;
import primitives.Color;
import primitives.Point3D;

/** Class Point light is the class representing a light source form a certain point, meaning a specific light source.
 * it makes all colors of point in specific geometries brighter or less brighter.
 * 
 * @author rajel and ruth
 *
 */
public class PointLight extends Light implements LightSource
{

	private Point3D position;
	private double kC = 1, kL = 0, kQ = 0; // atenuation factors
	
	
	
	
	/**
	 * @param intensity
	 * @param position
	 * @param kC
	 * @param kL
	 * @param kQ
	 */
	 public PointLight(Color intensity, Point3D p, double kC, double kL, double kQ) {
		super(intensity);
		this.position = p;
		this.kC = kC;
		this.kL = kL;
		this.kQ = kQ;
	}
	 
	 /**
	  * basic constructor for point light
	  * @param intensity
	  * @param position
	  */
	 public PointLight(Color intensity, Point3D p) {
		super(intensity);
		this.position = p;
	}
	/**
	 * @param kL the kL to set
	 */
	public PointLight setkL(double kl) {
		this.kL = kl;
		return this;
	}


	/**
	 * @param kQ the kQ to set
	 */
	public PointLight setkQ(double kq) {
		this.kQ = kq;
		return this;
	}

	@Override
	public Color getIntensity(Point3D p) 
	{
		//function for spot light is:
		//intensity = (intensity)/(KC + KL* direction + KQ * direction^2)
		 double d = p.distance(position);
		 double dSquared = p.distanceSqueared(position);
         return getIntensity().scale(1/(this.kC + ( this.kL * d ) + ( this.kQ *dSquared)));
	 
	}

	
	@Override
	public Vector getL(Point3D p) 
	{
		return p.subtract(position).normalized();
	}

	 
	 /**
	  *  double getDistance - Returns the distance between the point and the light source
	  */
	 public double getDistance(Point3D point)
	 {
		 return position.distance(point);
	 }

	@Override
	public Point3D getPosition() {
		return position;
	}

}
