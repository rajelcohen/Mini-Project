package scene;
import primitives.*;

import java.util.LinkedList;
import java.util.List;

import elements.*;
import geometries.*;

/**
 * Scene class combines all image neccesities to build one uniformed scene, where the image, geometries, light and shades combine together.
 * 
 * @author rajel and ruth
 */
public class Scene 
{
	
	/**
	 * all info in scene, name, lights, background, ambient light, and geometries...
	 */
	public String name;
    public List<LightSource> light = new LinkedList<LightSource>();
	public Color background = Color.BLACK;
	public AmbientLight ambientLight = new AmbientLight(background, 0);
	public Geometries geometries;
	
	/**
	 * scene advanced constructor
	 * @param _name
	 * @param _background
	 * @param _ambientLight
	 * @param _geometries
	 */
	public Scene(String _name, Color _background, AmbientLight _ambientLight, Geometries _geometries) {
		this.name = _name;
		this.background = _background;
		this.ambientLight = _ambientLight;
		this.geometries = _geometries;
	}
	
	/**
	 * scene basic constructor
	 * @param name
	 */
	public Scene(String n)
	{
		name = n;
		geometries = new Geometries();
		
	}
	
	/**
	 * sets light
	 * @param light the light to set
	 */
	public Scene setLight(List<LightSource>l)
	{
		light = l;
		return this;
	}
	
	

	


	/**
	 * sets background
	 * @param color
	 * @return this
	 */
	public Scene setBackround(Color b)
	{
		background = b;
		return this;
		
	}
	
	/**
	 * sets ambient light
	 * @param ambientlight
	 * @return this
	 */
	public Scene setAmbientLight(AmbientLight a)
	{
		ambientLight = a;
		return this;
	}
	
	/**
	 * set geometries
	 * @param geometries
	 * @return this
	 */
	public Scene setGeometries(Geometries g)
	{
		geometries = g;
		return this;
	}

}
