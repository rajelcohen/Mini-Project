package primitives;

/**
 * * Class point3d is the basic class representing a point3d for a 3d Cartesian
 * coordinate system . The class is based on Util controlling the accuracy.
 * @author rajel and ruty
 *
 */
public final class Point3D 
{
	//this needs to be converted to final.
	
     final Coordinate x;
     final Coordinate y;
	 final Coordinate z;
    
    public static Point3D ZERO = new Point3D(0.0, 0.0, 0.0);
   
    /**
     * get x
     * @return x
     */
	public Coordinate getX() {
		return x;
	}

	
	/**
	 * get y
	 * @return y
	 */
	public Coordinate getY() {
		return y;
	}
	

	
	/**
	 * get z
	 * @return z
	 */
	public Coordinate getZ() {
		return z;
	}

	
	
	
	/**
	 * point3d constructor receiving a point3d value
	 * 
	 * @param x value
	 * @param y value
	 * @param z value
	 * 
	 */
	public Point3D(Coordinate x, Coordinate y, Coordinate z) {
		super();
		this.x = x;
		this.y = y;
		this.z = z;
		
	}
	
	/**
	 * 
	 * constructor point
	 * @param x
	 * @param y
	 * @param z
	 */
	public Point3D(double x, double y, double z) {
		
		this(new Coordinate(x), new Coordinate(y), new Coordinate(z));
		
	}

	@Override
	public String toString() {
		return "Point3D [x=" + x.toString() + ", y=" + y.toString() + ", z=" + z.toString() + "]";
	}
	
	
	//functions:
	
	
	/**
	 * adds a new vector recieving value vector
	 * @param v
	 * @return
	 */
	public Point3D add(Vector v)
	{
		
		Coordinate cx = new Coordinate(v.head.x.coord + x.coord);
		Coordinate cy = new Coordinate(v.head.y.coord + y.coord);
		Coordinate cz = new Coordinate(v.head.z.coord + z.coord);
		
		Point3D p = new Point3D(cx, cy, cz);
		return p;
	}
	
	/**
	 * substracts vector recieving value vector
	 * @param p
	 * @return
	 */
	public Vector subtract(Point3D p) 
	{
		Coordinate cx = new Coordinate(x.coord - p.x.coord);
		Coordinate cy = new Coordinate(y.coord - p.y.coord);
		Coordinate cz = new Coordinate(z.coord - p.z.coord);
		Point3D m = new Point3D(cx, cy, cz);
		
		Vector vector = new Vector(m);
		
		return vector;
			
	}
	
	/**
	 * square distance between this point3d and recieved value of point3d
	 * @param p
	 * @return
	 */
	public double distanceSqueared(Point3D p)
	{
		double dis =  ((p.x.coord-x.coord)*(p.x.coord-x.coord) + (p.y.coord - y.coord)*(p.y.coord - y.coord) + (p.z.coord - z.coord)*(p.z.coord - z.coord));
		return dis;
		
	}
	
	
	/**
	 * distance between this point3d and recieved value of point3d
	 * @param p
	 * @return
	 */
	public double distance(Point3D p)
	{
		double dis = distanceSqueared(p);
		return Math.sqrt(dis);
	}
	
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Point3D other = (Point3D) obj;
		
		return x.equals(other.x) && y.equals(other.y) && z.equals(other.z);		
	}
	
	
	
	
	
}
