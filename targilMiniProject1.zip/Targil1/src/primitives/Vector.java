package primitives;

import static primitives.Point3D.ZERO;
import static primitives.Util.alignZero;
import static primitives.Util.isZero;

/**
 * Class vector is the basic class representing a vector for Cartesian
 * coordinate system. given value of a Point3d The class is based on Util controlling the accuracy.
 * @author rajel and ruty
 *
 */
public class Vector 
{
	Point3D head;

	/**
	 * 
	 * @return head
	 */
	public Point3D getHead() {
		return head;
	}

	/**
	 * 
	 * @param head value
	 */
	public void setHead(Point3D head) {
		this.head = head;
	}

	/**
	 * vector constructor receiving a Point3d value
	 * @param head
	 * @throws IllegalArgumentException when given incorrect value of point3d
	 */
	public Vector(Point3D head) throws IllegalArgumentException  
	{
		try
		{
			if(ZERO.equals(head))
			{
				throw new IllegalArgumentException("head of vector can't be Point(0,0,0)");
				
			}
			else
				this.head = head;
		}
		catch(IllegalArgumentException  io)
		{
			throw io;
		
		}
			
	}
	
	/**
	 * vector constructor receiving 3 double values for construction of point3d
	 * @param x
	 * @param y
	 * @param z
	 */
	public Vector(double x, double y, double z)
	{
		this(new Point3D(x, y, z));
	}
	
	
	@Override
	public String toString() {
		return "Vector [head=" + head.toString() + "]";
	}
	
	//functions:
	
	/**
	 * adding vector with value of new vector
	 * @param v
	 * @return
	 */
	public Vector add(Vector v)
	{
		Coordinate cx = new Coordinate(v.head.x.coord + this.head.x.coord);
		Coordinate cy = new Coordinate(v.head.y.coord + this.head.y.coord);
		Coordinate cz = new Coordinate(v.head.z.coord + this.head.z.coord);
		
		Point3D p = new Point3D(cx, cy, cz);
		Vector vec = new Vector(p);
		return vec;
		
	}
	
	
	/**
	 * subtract vector with value of new vector
	 * @param v
	 * @return
	 */
	public Vector subtract(Vector v)
	{
		if(v.equals(this))
		{
			throw new IllegalArgumentException("parameter vector can't be equal to me");
		}
		else
		{
			Coordinate cx = new Coordinate(v.head.x.coord - this.head.x.coord);
			Coordinate cy = new Coordinate(v.head.y.coord - this.head.y.coord);
			Coordinate cz = new Coordinate(v.head.z.coord - this.head.z.coord);
			
			Point3D p = new Point3D(cx, cy, cz);
			Vector vec = new Vector(p);
			return vec;
		}
		
	}
	
	/**
	 * multiplying vector with value of double
	 * @param d
	 * @return
	 */
	public Vector scale(double d)
	{
		if(d == 0 || alignZero(d) == 0)
		{
			throw new IllegalArgumentException("multiplier can't be 0");
		}
		else
		{
			Coordinate cx = new Coordinate(d *  this.head.x.coord);
			Coordinate cy = new Coordinate(d *  this.head.y.coord);
			Coordinate cz = new Coordinate(d * this.head.z.coord);
			
			Point3D p = new Point3D(cx, cy, cz);
			Vector vec = new Vector(p);
			return vec;
		}
		
	}
	
	/**
	 * crossProduct of vector with new value of vector
	 * @param v
	 * @return
	 */
	public Vector crossProduct(Vector v)
	{
		Coordinate cx = new Coordinate(this.head.y.coord * v.head.z.coord - this.head.z.coord*v.head.y.coord);
		Coordinate cy = new Coordinate(this.head.z.coord * v.head.x.coord - this.head.x.coord*v.head.z.coord);
		Coordinate cz = new Coordinate(this.head.x.coord*v.head.y.coord - this.head.y.coord*v.head.x.coord);
		
		Point3D p = new Point3D(cx,cy,cz);
		if(p.equals(ZERO))
		{
			throw new IllegalArgumentException("Error: crossproduct is returning vector 0");
		}
		else
		{
			Vector vec = new Vector(p);
			return vec;
		}
		
	}
	
	/**
	 * dotproduct of vector with value of new vector
	 * @param v
	 * @return
	 */
	public double dotProduct(Vector v)
	{
		double p = (v.head.x.coord * this.head.x.coord) + (v.head.y.coord * this.head.y.coord) + (v.head.z.coord * this.head.z.coord);
		return p;
	}
	
	/**\
	 * squared length of vector, 
	 * @return
	 */
	public double lengthSquared()
	{
		double xx = this.head.x.coord*this.head.x.coord;
		double yy = this.head.y.coord*this.head.y.coord;
		double zz = this.head.z.coord*this.head.z.coord;
		
		return(xx+yy+zz);
	}
	
	/**\
	 * length of vector
	 * @return
	 */
	public double length()
	{
		return(Math.sqrt(this.lengthSquared()));
	}
	
	/**
	 * normalization of this vector
	 * @return
	 */
	public Vector normalize()
	{
		double len = length();
		if(isZero(len))
		{
			throw new IllegalArgumentException("length equals 0");
		}
		else
		{
			double x = this.head.x.coord/len;
			double y = this.head.y.coord/len;
			double z = this.head.z.coord/len;
			
			this.head = new Point3D(x, y, z);
			
			return this;
			
		}
		
	}
	/**
	 * normalization of vector
	 * @return
	 */
	public Vector normalized()
	{
		Vector r = new Vector(head);
		r.normalize();
		this.normalize();
		return r;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		
		Vector other = (Vector) obj;
		
		return head.equals(other.head);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
