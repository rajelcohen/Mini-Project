package geometries;

import java.util.List;
import primitives.*;
import static primitives.Util.*;
/**
 *  geometry class represents inteface all geometries in system.
 * @author rajel and ruty
 *
 *
 */
public abstract class Geometry implements Intersectable
{
	protected Color emmission = Color.BLACK; //by starters there is no color in scene
	private Material material = new Material(); //all geometries have a material making it possible to have transparency and reflection on some.

	//public abstract Vector getNormal (Point3D point);
	
	
	/**
	 * @return the material
	 */
	public Material getMaterial() {
		return material;
	}
	
	/**
	 * set material
	 * @param m
	 * @return
	 */
	public Geometry setMaterial(Material m)
	{
		material = m;
		return this;
	}


	/**
	 * get emmision
	 * @return the emmission
	 */
	public Color getEmmission() {
		return emmission;
	}
	
	/**
	 * @paran the emmission
	 * @return this
	 */
	public Geometry setEmmission(Color n) {
		emmission = n;
		return this;
	}
	

	/**
	 * Normalization function acording to the class
	 * @param p
	 * @return
	 */
	public abstract Vector getNormal(Point3D p);


	
	
}
