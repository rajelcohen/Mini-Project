package geometries;

import java.util.ArrayList;
import java.util.List;

import geometries.Intersectable.GeoPoint;
import primitives.*;
import static primitives.Util.*;

import static primitives.Point3D.ZERO;

/**
 * triangle class represents two-dimensional triangle in 3D Cartesian coordinate
 * system, that is inherited from polygon
 * @author rajel and ruty
 *
 */
public class Triangle extends Polygon
{

	/**
	 * constructor for triangle based on 3 points
	 * @param a
	 * @param b
	 * @param c
	 */
	public Triangle(Point3D a, Point3D b, Point3D c)
	{
		super(a,b,c);
	}
	
	/**
	 * Returns cutting points of the body with the ray (if there are such points)
	 */
	public List<Point3D> findIntersections(Ray r) {

		// Check if there is at least one intersection point on the plane
		Plane plane = this.plane;
		double nv = plane.normal.dotProduct(r.getDir());
		if (isZero(nv))
			return null;
		if (plane.q0.equals(r.getP0())) // if the ray start at the center of the plane
			return null;
		double nQMinusP0 = plane.normal.dotProduct(plane.q0.subtract(r.getP0()));
		double tDistance = alignZero(nQMinusP0 / nv); // t = n*(Q-p0 )/ n*v
		if (tDistance <= 0)
			return null;

		Point3D P = r.getPoint(tDistance); // P = p0 + t* v

		Point3D p1 = this.vertices.get(0);
		Point3D p2 = this.vertices.get(1);
		Point3D p3 = this.vertices.get(2);

		if (p1.equals(r.getP0()) || p2.equals(r.getP0()) || p3.equals(r.getP0())) // if the point is on the vertex
			return null;

		Vector v1 = p1.subtract(r.getP0());
		Vector v2 = p2.subtract(r.getP0());
		Vector v3 = p3.subtract(r.getP0());

		Vector n1 = v1.crossProduct(v2);
		n1.normalize();

		Vector n2 = v2.crossProduct(v3);
		n2.normalize();

		Vector n3 = v3.crossProduct(v1);
		n3.normalize();

		// The point is inside if all V*Ni have the same sign

		double vn1 = alignZero(r.getDir().dotProduct(n1));
		double vn2 = alignZero(r.getDir().dotProduct(n2));
		double vn3 = alignZero(r.getDir().dotProduct(n3));

		if ((vn1 > 0 && vn2 > 0 && vn3 > 0) || (vn1 < 0 && vn2 < 0 && vn3 < 0)) // if the Point is inside the triangle
		{

			List<Point3D> listOfIntersections = new ArrayList<Point3D>();
			listOfIntersections.add(P);

			return listOfIntersections;
		}

		return null;
	}
	
	/**
	 * Function that returns list of geopoints of all intersection of triangle and ray
	 */
	public List<GeoPoint> findGeoIntersections(Ray r) 
	{
		


		// Check if there is at least one intersection point on the plane
		Plane plane = this.plane;
		double nv = plane.normal.dotProduct(r.getDir());
		if (isZero(nv))
			return null;
		if (plane.q0.equals(r.getP0())) // if the ray start at the center of the plane
			return null;
		double nQMinusP0 = plane.normal.dotProduct(plane.q0.subtract(r.getP0()));
		double tDistance = alignZero(nQMinusP0 / nv); // t = n*(Q-p0 )/ n*v
		if (tDistance <= 0)
			return null;

		Point3D P = r.getPoint(tDistance); // P = p0 + t* v

		Point3D p1 = this.vertices.get(0);
		Point3D p2 = this.vertices.get(1);
		Point3D p3 = this.vertices.get(2);

		if (p1.equals(r.getP0()) || p2.equals(r.getP0()) || p3.equals(r.getP0())) // if the point is on the vertex
			return null;
		
		

		//explanation:
		//𝑣1 = 𝑃1 − 𝑃0
		//𝑣2 = 𝑃2 − 𝑃0
		//𝑣3 = 𝑃3 − 𝑃0

		Vector v1 = p1.subtract(r.getP0());
		Vector v2 = p2.subtract(r.getP0());
		Vector v3 = p3.subtract(r.getP0());

		Vector n1 = v1.crossProduct(v2);
		n1.normalize();

		Vector n2 = v2.crossProduct(v3);
		n2.normalize();

		Vector n3 = v3.crossProduct(v1);
		n3.normalize();

		// The point is inside if all V*Ni have the same sign

		double vn1 = alignZero(r.getDir().dotProduct(n1));
		double vn2 = alignZero(r.getDir().dotProduct(n2));
		double vn3 = alignZero(r.getDir().dotProduct(n3));
		//System.out.println(vn1 + " " + vn2 + " " + vn3);
		

		if ((vn1 > 0 && vn2 > 0 && vn3 > 0) || (vn1 < 0 && vn2 < 0 && vn3 < 0)) // if the Point is inside the triangle all have the same sign
		{

			List<GeoPoint> listOfIntersections = new ArrayList<GeoPoint>();
			listOfIntersections.add(new GeoPoint(this,P));
			return listOfIntersections;
		}

		return null;
	}
		
	}