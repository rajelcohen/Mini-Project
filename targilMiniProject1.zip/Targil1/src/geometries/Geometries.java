package geometries;

import java.util.LinkedList;
import java.util.List;

import primitives.Point3D;
import primitives.Ray;

/**
 *  geometries interface represents list of possibly all geometries in system.
 * @author rajel and ruty
 *
 */
public class Geometries implements Intersectable 
{
	
	//list
	 List <Intersectable> intersectables;

	 /**
	  * creation of list
	  */
	   public Geometries() {
	       intersectables = new LinkedList<>();
	    }

	   /**
	    * adding to list
	    * @param intersectables
	    */
	    public void add (Intersectable... intersectables)
	    {
	        for (Intersectable item : intersectables)
	            this.intersectables.add(item);

	    }

	    
	    /**
	     * basic constructor with list included
	     * @param intersectables
	     */
	    public Geometries(Intersectable... intersectables ) {
	       this.intersectables= new LinkedList<>();
	       add(intersectables);
	    }

	  
	    /**
	     * function returnning the intersections, points of connection between ray that was sent and all geometries in list 
	     */
		@Override
		public List<GeoPoint> findGeoIntersections(Ray ray) 
		{
			  List<GeoPoint> result = null;

		       for (Intersectable item : this.intersectables ) {
		           List <GeoPoint> itemPoints = item.findGeoIntersections(ray); //each geometry checks if ray has intersections
		           if(itemPoints!= null){ //if it does, it adds them to new list
		               if (result == null){
		                   result = new LinkedList<>();
		               }
		               result.addAll(itemPoints);
		           }


		       }

		       return result; //returns list of all junctions
			
		}

}
