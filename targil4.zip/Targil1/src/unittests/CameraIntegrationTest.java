package unittests;

import static org.junit.Assert.*;

import java.util.LinkedList;
import java.util.List;

import org.junit.Test;

import elements.Camera;
import geometries.Geometries;
import geometries.Geometry;
import geometries.Plane;
import geometries.Sphere;
import geometries.Triangle;
import primitives.*;
/**
 * /**
 * @author rajel and ruth
 *  * Unit tests for elements.camera class integration with geometries classes
 *
 *
 */
public class CameraIntegrationTest 
{
	
	/**
	 * function to help other functions in this class
	 * @param indexi
	 * @param indexj
	 * @param sphere
	 * @param c
	 * @param allPoints
	 */
	public void functionfor(int indexi,int indexj, Geometry sphere, Camera c, List<Point3D> allPoints)
	{
		for(int i = 0; i < indexi; i++) 
		{
			for(int j = 0; j < indexj; j++)
			{
				Ray ray = c.constructRayThroughPixel(3, 3, j, i);
				List<Point3D> lst = sphere.findIntersections(ray);
				if(lst!=null)
				{
					if(allPoints == null)
						allPoints = new LinkedList<>();
					allPoints.addAll(lst);
				}
				
			}
		}
	}
	
	
	
	/**
	 * 
	 * Test method for {@link elements.camera#setViewPlaneSize(geometries.sphere)}.
	 *
	 */
	@Test
	public void testspherewithcam() 
	{
		//test sphere 1
		Sphere sphere = new Sphere(new Point3D(0, 0, -3), 1);
		
		Camera cam = new Camera(Point3D.ZERO, new Vector(0,0,-1), new Vector(0,1,0)).setDistance(1).setViewPlaneSize(3, 3);
		
		List<Point3D> allPoints = new LinkedList<>();
		
		functionfor(3, 3, sphere, cam, allPoints);
			
		assertEquals("wrong number of intersections", allPoints.size(), 2);
	
		
		
		
		//test sphere 2
		Sphere sphere2 = new Sphere(new Point3D(0, 0, -2.5), 2.5);
		
		Camera cam2 = new Camera(new Point3D(0, 0, 0.5), new Vector(0,0,-1), new Vector(0,1,0)).setDistance(1).setViewPlaneSize(3, 3);
		
		List<Point3D> allPoints2 = new LinkedList<>();
		
		functionfor(3, 3, sphere2, cam2, allPoints2);
	
		assertEquals("wrong number of intersections", allPoints2.size(), 18);
	
		
		//test sphere 3
		Sphere sphere3 = new Sphere(new Point3D(0, 0, -2), 2);
		
		Camera cam3 = new Camera(new Point3D(0, 0, 0.5), new Vector(0,0,-1), new Vector(0,1,0)).setDistance(1).setViewPlaneSize(3, 3);
		
		List<Point3D> allPoints3 = new LinkedList<>();
		functionfor(3, 3, sphere3, cam3, allPoints3);
			
		assertEquals("wrong number of intersections", allPoints3.size(), 10);
	
		
		//test sphere 4 - 
		Sphere sphere4 = new Sphere(new Point3D(0, 0, 1), 4);
		
		Camera cam4 = new Camera(new Point3D(0, 0, 0.5), new Vector(0,0,-1), new Vector(0,1,0)).setDistance(1).setViewPlaneSize(3, 3);
		
		List<Point3D> allPoints4 = new LinkedList<>();
		
		functionfor(3, 3, sphere4, cam4, allPoints4);
			
		assertEquals("wrong number of intersections", allPoints4.size(), 9);
	
		
		//test sphere 5
		Sphere sphere5 = new Sphere(new Point3D(0, 0, 1), 0.5);
		
		Camera cam5 = new Camera(new Point3D(0, 0, 0), new Vector(0,0,-1), new Vector(0,1,0)).setDistance(1).setViewPlaneSize(3, 3);
		
		List<Point3D> allPoints5 = new LinkedList<>();
		
		functionfor(3, 3, sphere5, cam5, allPoints5);
			
		assertEquals("wrong number of intersections", allPoints5.size(), 0);
	
	}
	
	/**
	 * 
	 * Test method for {@link elements.camera#setViewPlaneSize(geometries.plane)}.
	 *
	 */
	@Test
	public void testplanewithcam() 
	{
		//test plane 1 - parallel to view plane
		Plane plane = new Plane(new Point3D(0, 0, -3), new Point3D(1, 0, -3), new Point3D(-2, 1, -3));
		
		Camera cam = new Camera(new Point3D(0, 0, 0), new Vector(0,0,-1), new Vector(0,1,0)).setDistance(1).setViewPlaneSize(3, 3);
		
		List<Point3D> allPoints = new LinkedList<>();
		
		functionfor(3, 3, plane, cam, allPoints);
			
		assertEquals("wrong number of intersections", allPoints.size(), 9);
		
		//test plane 2 - not parallel to view plane
		Plane plane2 = new Plane(new Point3D(0, 0, -4), new Point3D(0, 1.2, -3.61), new Point3D(1.52, -1.52, -4.55));
		
		Camera cam2 = new Camera(new Point3D(0, 0, 0), new Vector(0,0,-1), new Vector(0,1,0)).setDistance(1).setViewPlaneSize(3, 3);
		
		List<Point3D> allPoints2 = new LinkedList<>();
		
		functionfor(3, 3, plane2, cam2, allPoints2);
			
		assertEquals("wrong number of intersections", allPoints2.size(), 9);
	
		
		//test plane 3 - parallel to some of the rays
		Plane plane3 = new Plane(new Point3D(0, 0, -2), new Vector( 0,1, -1));
		
		Camera cam3 = new Camera(new Point3D(0, 0, 0), new Vector(0,0,-1), new Vector(0,1,0)).setDistance(1).setViewPlaneSize(3, 3);
		
		List<Point3D> allPoints3 = new LinkedList<>();
		
		functionfor(3, 3, plane3, cam3, allPoints3);
			
		assertEquals("wrong number of intersections", allPoints3.size(), 6);
	
	}
	
	/**
	 * 
	 * Test method for {@link elements.camera#setViewPlaneSize(geometries.triangle )}.
	 *
	 */
	@Test
	public void testtriaglewithcam() 
	{
		//test triangle 1 - much smaller than view plane
		Triangle triangle = new Triangle(new Point3D(0, 1, -2), new Point3D(-1, -1, -2), new Point3D(1, -1,-2));
		
		Camera cam= new Camera(new Point3D(0, 0, 0.5), new Vector(0,0,-1), new Vector(0,1,0)).setDistance(1).setViewPlaneSize(3, 3);
		
		List<Point3D> allPoints = new LinkedList<>();
		
		functionfor(3, 3, triangle, cam, allPoints);
			
		assertEquals("wrong number of intersections", allPoints.size(), 1);
	
		
		//test triangle 2 -bigger
		Triangle triangle1 = new Triangle(new Point3D(0, 20, -2), new Point3D(-1, -1, -2), new Point3D(1, -1,-2));
		
		Camera cam1 = new Camera(new Point3D(0, 0, 0.5), new Vector(0,0,-1), new Vector(0,1,0)).setDistance(1).setViewPlaneSize(3, 3);
		
		List<Point3D> allPoints1 = new LinkedList<>();
		
		functionfor(3, 3, triangle1, cam1, allPoints1);
			
		assertEquals("wrong number of intersections", allPoints1.size(), 2);
	
	
		
		
	}
	
	

}
