package targil0;

import java.util.Objects;

/**
 * @author rosen
 *
 */
public abstract class Employee
{
	String firstName;
	String lastName;
	String id;
	
	Employee()
	{
		firstName = "plony";
		lastName = "almony";
		id = "0";		
	}
	
	public Employee(String newFirstName, String newLastName, String newId) throws Exception
	{
		firstName = newFirstName;
		lastName = newLastName;
		setId(newId);
	}
	
	public void setFirstName(String newFirstName)
	{
		firstName = newFirstName;	
	}
	
	public void setLastName(String newLastName)
	{
		lastName = newLastName;	
	}
	
	public void setId(String newId) throws Exception
	{
		try
		{
			if (newId.length()==8 || newId.length()==9)
				id = newId;	
			else throw new Exception ("the id is incorrect.");
		}
		catch (Exception e)
		{
			throw e;
		}	
	}
	
	public String getFirstName()
	{
		return firstName;
	}
	
	public String getLastName()
	{
		return lastName;
	}
	
	public String getId()
	{
		return id;
	}
	
	@Override
	public String toString()
	{
		return "Employee: firstName- "+ firstName+ " lastName- "+ lastName+ " id- "+ id;
	}
	
	@Override
	public boolean equals(Object o)
	{
		if (this == o)
			return true;
		if (o ==null || o.getClass() != getClass())
			return false;
		Employee e = (Employee) o;
		return e.firstName== firstName && e.lastName ==lastName && e.id ==id;
	}
	
	@Override
	public int hashCode()
	{
		return Objects.hash(firstName, lastName, id);
	}
	
	public abstract double earnings();
	
	

}
