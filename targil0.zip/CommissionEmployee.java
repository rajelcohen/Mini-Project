package targil0;

import java.util.Hashtable;
import java.util.Objects;

public class CommissionEmployee extends Employee
{
	float grossSales;
	int commision;
	
	public CommissionEmployee()
	{
		super();
		grossSales = 0;
		commision = 0;		
	}
	
	public CommissionEmployee(String newFirstName, String newLastName, String newId,float newGrossSales, int newCommision) throws Exception
	{
		super(newFirstName, newLastName, newId);	
		grossSales = newGrossSales;
		commision = newCommision;
		
	}
	
	public int getCommision()
	{
		return commision;
	}
	
	public float getGrossSales()
	{
		return grossSales;
	}
	
	public void setCommision(int commision) throws Exception
	{
		try
		{
			if (commision > 0)
				this.commision = commision;
		
			else throw new Exception ("the commision is incorrect.");
		}
			catch (Exception e)
			{
				throw e;
			}
	}
	
	public void setGrossSales(float grossSales) throws Exception
	{
		try
		{
			if (grossSales > 0)
				this.grossSales = grossSales;
		
			else throw new Exception ("the grossSales is incorrect.");
		}
			catch (Exception e)
			{
				throw e;
			}
	}
	
	@Override
	public String toString()
	{
	      
	      return super.toString()+ " commision- "+commision+" grossSales- "+grossSales;
	}

	@Override
	public boolean equals(Object o)
	{
		if (this == o)
			return true;
		if (o ==null || o.getClass() != getClass())
			return false;
		CommissionEmployee e = (CommissionEmployee) o;
		return  super.equals(o) && grossSales == e.grossSales && commision ==e.commision;	}
	
	@Override
	public int hashCode() 
	{
		super.hashCode();
		return Objects.hash(grossSales, commision);
	}
	
	@Override
	public double earnings() 
	{
		return (commision / 100) * grossSales;
	}
	
	

}
