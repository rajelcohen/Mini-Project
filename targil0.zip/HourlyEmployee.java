package targil0;

import java.util.Objects;

public class HourlyEmployee extends Employee
{
	int hours;
	float wage;
	
	public HourlyEmployee()
	{
		super();
		hours = 0;
		wage = 0;
	}
	
	public HourlyEmployee(String newFirstName, String newLastName, String newId, int newHours, float newWage) throws Exception 
	{
		super(newFirstName, newLastName, newId);
		setWage(newWage);
		setHours(newHours);
	}
	
	public int getHours()
	{
		return hours;
	}
	
	public float getWage()
	{
		return wage;
	}
	
	public void setHours(int newHours) throws Exception
	{
		try
		{
			if (newHours > 0)
				hours = newHours;
		
			else throw new Exception ("the hours is incorrect.");
		}
			catch (Exception e)
			{
				throw e;
			}
	}

	public void setWage(float newWage) throws Exception
	{
		try
		{
			if (newWage > 0)
				wage = newWage;
		
			else throw new Exception ("the wage is incorrect.");
		}
			catch (Exception e)
			{
				throw e;
			}
		
	}
	
	@Override
	public String toString()
	{
		
		return super.toString() + " hours- "+hours+ " wage- "+wage;
	}
	
	@Override
	public boolean equals(Object o)
	{
		if (this == o)
			return true;
		if (o ==null || o.getClass() != getClass())
			return false;
		HourlyEmployee e = (HourlyEmployee) o;
		return  super.equals(o) && hours == e.hours && wage ==e.wage;
	}
	
	@Override
	public int hashCode()
	{
		super.hashCode();
		return Objects.hash( hours, wage);
	}
	
	@Override
	public double earnings() 
	{
		return hours * wage;
	}
	
	

}
