package targil0;

import java.util.Objects;

public class BasePlusCommissionEmployee extends CommissionEmployee
{
	float baseSalary;
	
	public BasePlusCommissionEmployee()
	{
		super();
		baseSalary =0;
	}
	
	public BasePlusCommissionEmployee(String newFirstName, String newLastName, String newId,float newGrossSales, int newCommision,float newBaseSalary) throws Exception
	{
		super( newFirstName,  newLastName,  newId, newGrossSales,  newCommision);
		setBaseSalary(newBaseSalary);
	}
	
	public float getBaseSalary()
	{
		return baseSalary;
	}
	
	public void setBaseSalary(float baseSalary) throws Exception
	{
		try
		{
			if (commision > 0)
				this.baseSalary = baseSalary;
		
			else throw new Exception ("the baseSalary is incorrect.");
		}
			catch (Exception e)
			{
				throw e;
			}	
	}
	
	@Override
	public String toString()
	{
		 
		 return super.toString()+ " baseSalary- "+baseSalary;
	}
	
	@Override
	public int hashCode() 
	{
		super.hashCode();
		return Objects.hash(baseSalary);
	}

	@Override
	public boolean equals(Object o)
	{
		if (this == o)
			return true;
		if (o ==null || o.getClass() != getClass())
			return false;
		BasePlusCommissionEmployee e = (BasePlusCommissionEmployee) o;
		return super.equals(o) && baseSalary==e.baseSalary ;
	}

	public double earings() 
	{
		return super.earnings() + baseSalary;
	}
	
	
}
