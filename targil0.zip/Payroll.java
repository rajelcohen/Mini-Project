package targil0;


import java.util.*;

public class Payroll {

	public static void main(String[] args) throws Exception
	{
		Scanner input= new Scanner(System.in);

		Employee[] arr = new Employee[3];
		
		String firstName;
		String lastName;
		String id;
		int hours;
		float wage;
		float grossSales;
		int commision;
		float baseSalary;
		
			while(arr[0] == null)
			{
		System.out.println("enter details for a HourlyEmployee");
		firstName = input.next();
		lastName = input.next();
		id = input.next();
		hours = input.nextInt();
		wage = input.nextFloat();
		
		try
		{
		arr[0]= new HourlyEmployee(firstName, lastName, id, hours, wage);
		System.out.println(arr[0].toString());
		System.out.println("the earnings are: "+arr[0].earnings());
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
			}
		
			while(arr[1] == null)
			{
		System.out.println("enter details for a CommissionEmployee");
		firstName = input.next();
		lastName = input.next();
		id = input.next();
		grossSales =  input.nextFloat();
		commision =input.nextInt();
		
		try
		{
		arr[1]=new CommissionEmployee(firstName, lastName, id, grossSales, commision);
		System.out.println(arr[1].toString());
		System.out.println("the earnings are: "+arr[1].earnings());
		}
		catch (Exception e) 
		{
			System.out.println(e);
		}
			}
			while(arr[2] == null )
			{
		System.out.println("enter details for a BasePlusCommissionEmployee");
		firstName = input.next();
		lastName = input.next();
		id = input.next();
		grossSales =  input.nextFloat();
		commision =input.nextInt() + 10;
		baseSalary = input.nextFloat();

			try
			{
		arr[2] =new BasePlusCommissionEmployee(firstName, lastName, id, grossSales, commision, baseSalary);
		System.out.println(arr[2].toString());
		System.out.println("the earnings are: "+arr[2].earnings());
			}
			catch (Exception e) 
			{
				System.out.println(e);
			}	
			}
			


	}

}
