/**
 * 
 */
package unittests;
import primitives.*;

import geometries.Triangle;
import static java.lang.System.out;
import static org.junit.Assert.*;
import static primitives.Util.isZero;

import java.util.List;

import org.junit.Test;

import geometries.Triangle;

/**
 * @author rajel and rut
 * * Unit tests for primitives.Triangle class
 *
 */
public class TriangleTest {

	/**
	 * Test method for {@link geometries.Polygon#getNormal(primitives.Point3D)}.
	 */
	@Test
	public void testGetNormal() 
	{
		Triangle p = new Triangle(new Point3D(0, 0, 1), new Point3D(1, 0, 0), new Point3D(0, 1, 0));
        double sqrt3 = Math.sqrt(1d/ 3);
        assertEquals("Bad normal to trinagle", new Vector(sqrt3, sqrt3, sqrt3), p.getNormal(new Point3D(0, 0, 1)));
    
		
	}
	
	
	/**
	 * Test method for {@link geometries.Triangle#findIntersections(primitives.Point3D)}.
	 */
	public void testFindIntersections() 
	{
		
		Triangle triangle = new Triangle(new Point3D(0, -2, 0), new Point3D(0, 0, 4), new Point3D(0, 2, 0));
		//EP- 
		//test1 - inside triangle
		List<Point3D> result1 = triangle.findIntersections(new Ray(new Point3D(2.56, -2.68, 0),new Vector(-2.56, 2.63, 2)));
        assertEquals("Wrong number of points", 1, result1.size());
	
		//test2 - outside triangle, in edge 
        assertNull("Ray's line out of triangle", triangle.findIntersections(new Ray(new Point3D(1.56, -2.28, 0),new Vector(-1.56, 0.06, 1.04))));
        
		//test3 - outside triangle, in vertex
		
        assertNull("Ray's line out of triangle", triangle.findIntersections(new Ray(new Point3D(2.56, -2.63, 0),new Vector(-2.56, -1.11, -1))));
        
		//BVA - ray begins before
		//test4 - on edge
        
        List<Point3D> result4 = triangle.findIntersections(new Ray(new Point3D(1.56, -2.28, 0),new Vector(-1.56, 0.66, 0.76)));
        assertEquals("Wrong number of points", 1, result4.size());
	
		//test5 - in vertex
        
        List<Point3D> result5 = triangle.findIntersections(new Ray(new Point3D(1.56, -2.28, 0),new Vector(-1.56, 0.28, 0)));
        assertEquals("Wrong number of points", 1, result5.size());
	
		//test6 - in edge's continuation
        
        assertNull("Ray's line out of triangle", triangle.findIntersections(new Ray(new Point3D(1.56, -2.28, 0),new Vector(-1.56, -0.07, -0.69))));
        
	
	}

}
