/**
 * 
 */
package unittests;

import static java.lang.System.out;
import static org.junit.Assert.*;
import static primitives.Util.isZero;

import org.junit.Test;

import primitives.Point3D;
import primitives.Vector;

/**
 * @author rajel
 * Unit tests for primitives.Point3D class
 *
 */
public class Point3DTests 
{

	

	
	 Point3D p1 = new Point3D(1, 2, 3); 
	 Vector v = new Vector(1,2,3);
	  

	/**
	 * Test method for {@link primitives.Point3D#add(primitives.Vector)}.
	 */
	@Test
	public void testAdd() 
	{
		 assertTrue("ERROR: Point.Add() -  does not work correctly", new Point3D(2, 2, 2).equals(new Point3D(1, 1, 1).add(new Vector(1,1,1))));
	     
	}

	/**
	 * Test method for {@link primitives.Point3D#subtract(primitives.Point3D)}.
	 */
	@Test
	public void testSubtract() 
	{
	     assertTrue("ERROR: Point.Substract() - does not work correctly", new Vector(1, 1, 1).equals(new Point3D(2, 3, 4).subtract(p1)));
	         
	}

	/**
	 * Test method for {@link primitives.Point3D#distanceSqueared(primitives.Point3D)}.
	 */
	@Test
	public void testDistanceSqueared() 
	{
		double x = new Point3D(1, 2, 3).distanceSqueared(p1);
		assertTrue("ERROR: Point.DistanceSquared() - does not work correctly", isZero(x));
	}

	/**
	 * Test method for {@link primitives.Point3D#distance(primitives.Point3D)}.
	 */
	@Test
	public void testDistance() 
	{
		double x = new Point3D(1, 2, 3).distance(p1);
		assertTrue("ERROR: Point.Distance) - does not work correctly", isZero(x));
	}

}
