/**
 * 
 */
package renderer;
import java.lang.Math;

import static primitives.Point3D.ZERO;
import static primitives.Util.alignZero;
import static primitives.Util.isZero;

import geometries.*;
import geometries.Intersectable;
import primitives.*;
import geometries.Intersectable.GeoPoint;
import java.awt.Image;
import java.util.MissingResourceException;

import java.util.List;

import geometries.Intersectable.GeoPoint;
import elements.*;
import scene.*;

import scene.Scene;

/**
 * basic - after base class of ray tracer, same as class raytracerbasic but here scene is present.
 * @author rajel
 * @return true if the point unshaded or false if the point shaded
 * */
public class RayTracerBasic extends RayTracerBase 
{
	
	private static final double DELTA = 0.1;

	private static final int MAX_CALC_COLOR_LEVEL = 10;
	private static final double MIN_CALC_COLOR_K = 0.001;
	
	/**
	 * 
	 * @param l
	 * @param n
	 * @param gp
	 * @return true if the point unshaded or false if the point shaded
	 */
	private boolean unshaded(Vector l, Vector n, GeoPoint gp)
	 {
		Vector lightDirection = l.scale(-1); // from point to light source
		Vector delta = n.scale(n.dotProduct(lightDirection) > 0 ? DELTA : - DELTA);
		Point3D point = gp.point.add(delta);
		
		Ray lightRay = new Ray(point, lightDirection);
		List<GeoPoint> intersections = scene.geometries.findGeoIntersections(lightRay);
		return intersections == null;
	}

	
	/*
	 * raytracerbasic constructor, recieves scene and creates from the base.
	 */
	public RayTracerBasic(Scene s) 
	{
		super(s);
		//return null;
	}
	/*
	 * function that gets all the scene intersections, and finds the closest points colors.
	 * @param ray
	 * @returns scene
	 */
	public Color traceRay(Ray ray)
	{
		var intersections = scene.geometries.findGeoIntersections(ray);
		if (intersections == null || intersections.isEmpty()) return scene.background;
		GeoPoint closestPoint = ray.findClosestGeoPoint(intersections);
		return calcColor(closestPoint, ray);
	}
	
	/*
	 * function that gets the ambient colors intensity
	 * @param point
	 * @return scene.ambientLight.getIntestity()
	 */
	private Color calcColor(GeoPoint point, Ray ray)
	{

		return scene.ambientLight.getIntensity().add(point.geometry.getEmmission()).add(callocalEffects(point, ray));
	}
	
	private Color callocalEffects(GeoPoint intersection, Ray ray)
	{
		Vector v = ray.getDir().normalize(); // Vector from camera to body
		Vector n = intersection.geometry.getNormal(intersection.point).normalize();
		Material m = intersection.geometry.getMaterial();
		//n.normalize();
		double nv = Util.alignZero(n.dotProduct(v));
		if (nv == 0)
			return Color.BLACK;
		int nShininess = intersection.geometry.getMaterial().nShininess;
		double kd = intersection.geometry.getMaterial().kD;
		double ks = intersection.geometry.getMaterial().kS;
		Color color = Color.BLACK;
		for (elements.LightSource lightSource : scene.light) 
		{
			Vector l = lightSource.getL(intersection.point).normalize(); // Vector from the light source to the point
			//l.normalize();
			double nl = Util.alignZero(n.dotProduct(l));
			if (nl * nv > 0) // If the camera and light source are not in opposite directions (sign(nl) ==sing(nv)
			{
				if(unshaded(lightSource, intersection))
				{
					Color lightIntensity = lightSource.getIntensity(intersection.point); // The intensity of the light source at a certain point
				    color = color.add(calcDiffusive(m, l, n, lightIntensity),calcSpecular(m, l, n, v, nShininess, lightIntensity));
				}
			
			}
			
		}
		// System.out.println(color);

		return color;
	}
	
	

	
	
	private boolean unshaded(LightSource lightSource, GeoPoint intersection)
	{
		Vector lightDirectional = lightSource.getL(intersection.point).scale(-1).normalize();
		Ray lightRay = new Ray(intersection, lightDirectional, DELTA);
		List<GeoPoint> i = scene.geometries.findGeoIntersections(lightRay);
		return i == null;
		
	}


	//private Color calcSpecular(Material material, Vector l, Vector n, Vector v, int nShininess, Color lightIntensity) 
	{
		
//		double ks = material.kS;
//		int nsh = material.nShininess;
//		Vector r = l.subtract(n.scale(2 * l.dotProduct(v))).normalize();
//		return lightIntensity.scale(Math.pow(-v.dotProduct(r), nsh));
//	
		
//		Vector lnn2 = n.scale(2 * l.dotProduct(n));
//		Vector r = lnn2.subtract(l).normalize(); // Calculating reflectance vector ( r = l - 2* (l*n)*n)
//		// r.normalize();
//		double vr = (v.dotProduct(r)) * -1; // -v * r
//		double max = Math.max(0, vr);
//		double num = Math.pow(max, nShininess);
//		return lightIntensity.scale(ks * num);
		
	}
	
	private Color calcSpecular(Material material, Vector l, Vector n, Vector v, int nShininess, Color lightIntensity)
	{
	// NEXT TWO LINES ARE MINE
  	double ks= material.kS;
	 double nl = Util.alignZero(n.dotProduct(l));
	 Vector r = l.add(n.scale(-2 * nl)); // nl must not be zero!
	 

	double vr = (v.dotProduct(r)) * -1; // -v * r

	double max = Math.max(0, vr);
	double num = Math.pow(max, nShininess);
	return lightIntensity.scale(ks * num);
	}
	
	
	private Color calcDiffusive(Material material, Vector l, Vector n, Color lightIntensity) 
	{
		double kd = material.kD;
		return lightIntensity.scale(Math.abs(l.dotProduct(n)) * kd);
	}

}
