package renderer;

import geometries.*;
import primitives.*;

import java.awt.Image;
import java.util.MissingResourceException;

import elements.*;
import scene.*;

/**
 * Render class combines accumulation of pixel color matrix gets the info on the giometries, and prmitives, and "renders" them all together, creaying one hole space.
 * 
 * @author rajel and ruth
 */
public class Render 
{
	Camera camera;
	ImageWriter imagewriter;
	RayTracerBase rayTracer;
	

	/*
	 * set camera
	 * @param camera
	 * @returns this changed
	 * 
	 */
	public Render setCamera(Camera c)
	{
		camera = c;
		return this;
	}
	
	

	/*
	 * set imagewriter
	 * @param imagewr
	 * @returns this changed
	 * 
	 */
	public Render setImageWriter(ImageWriter i)
	{
		imagewriter = i;
		return this;
	}
	

	/*
	 * set ray tracer
	 * @param ray tracer
	 * @returns this changed
	 * 
	 */
	public Render setRayTracer(RayTracerBase r)
	{
		rayTracer = r;
		return this;
	}
	/*
	 * function that created the image necessary for rendering, combining info recieved with function: constructRayThroughPixel();
	 * created the inage by using function: writeToImage();
	 * 
	 * 
	 */
	public void renderImage()
	{
		try
		{
			if(imagewriter == null)
				throw new MissingResourceException("missing resource info", ImageWriter.class.getName(), " ");
			if(camera == null)
				throw new MissingResourceException("missing resource info", Camera.class.getName(), " ");
			if(rayTracer == null)
				throw new MissingResourceException("missing resource info", RayTracerBasic.class.getName(), " ");
			int nX = imagewriter.getNx();
			int nY = imagewriter.getNy();
			for(int i = 0; i < nY; i++)
				for(int j = 0; j < nX; j++)
				{
					Ray ray = camera.constructRayThroughPixel(nX, nY, i, j);
					Color pixelColor = rayTracer.traceRay(ray);
					imagewriter.writePixel(i, j, pixelColor);
				}
			
		//	imagewriter.writeToImage();
		
		
		}
		catch(MissingResourceException e)
		{
			throw new UnsupportedOperationException("Not implemented yet" + e.getClassName());
		}
	}
	
	
	/*
	 * recieves information on the grid views color and the numbers of pixel, and sets all info recieved to it.
	 */
	public void printGrid(int interval, Color color)
	{
		if(imagewriter == null)
			throw new MissingResourceException("missing resource info", ImageWriter.class.getName(), " ");
		else
		{
			int nX = imagewriter.getNx();
			int nY = imagewriter.getNy();
			for(int i = 0; i < nY; i++)
			{
				for(int j = 0; j < nX; j++)
				{
					if(i%interval ==0 || j % interval == 0)
					{
						imagewriter.writePixel(i, j, color);
					}
				}
			}
			imagewriter.writeToImage();
		}
				
		
	}
	
	/*
	 * uses function writeToImage() from ImageWriter class
	 */
	public void writeToImage()
	{
		if(imagewriter == null)
			throw new MissingResourceException("missing resource info", ImageWriter.class.getName(), " ");
		else
		{
			imagewriter.writeToImage();
		}
			
	
	}
	
	
	
	
	

}
