package primitives;

import primitives.*;
import static primitives.Util.*;

import java.util.List;

import geometries.Intersectable.GeoPoint;


/**
 * * Class ray is the basic class representing a ray for Cartesian
 * coordinate system. given the value of the point3d and the direction. The class is based on Util controlling the accuracy.
 * @author rajel and ruty
 *
 */
public class Ray 
{
	Point3D p0;
	Vector dir;
	
	/**
	 * 
	 * @return p0
	 */
	public Point3D getP0() {
		return p0;
	}
	
	/**
	 * 
	 * @param p0 value
	 */
	public void setP0(Point3D p0) 
	{
		this.p0 = p0;
	}
	
	/**
	 * 
	 * @return dir
	 */
	public Vector getDir() {
		return new Vector(dir.head);
	}
	
	/**
	 * 
	 * @param dir value
	 */
	public void setDir(Vector dir) {
		this.dir = dir;
	}
	
	/**
	 * 
	 * ray constructor receiving a point3d value and vector value
	 * 
	 * @param p0
	 * @param dir
	 * @throws IllegalArgumentException when value of vector is incorrect
	 */
	public Ray(Point3D p0, Vector dir) throws IllegalArgumentException  
	{
		
		super();
		this.p0 = p0;
		this.dir = dir;
		this.dir.normalize();
	
		double n = ((dir.head.x.coord * dir.head.x.coord) + (dir.head.y.coord*dir.head.y.coord) + (dir.head.z.coord*dir.head.z.coord)) ;
		if(Math.sqrt(n) == 1) //is normalized
		{
			this.dir = dir;
		}
		else //in need of normalization
		{
			n = Math.sqrt(n);
			Coordinate cx = new Coordinate(dir.head.x.coord/n);
			Coordinate cy = new Coordinate(dir.head.y.coord/n);
			Coordinate cz = new Coordinate(dir.head.z.coord/n);
					
			Point3D p = new Point3D(cx, cy, cz);
			Vector nor = new Vector(p);
			
			this.dir = nor;
		}
		
		
	}
	public Ray(GeoPoint geoPoint, Vector lightDirectional, double delta)
	{
		Vector n = geoPoint.geometry.getNormal(geoPoint.point);
		Vector offset = n.scale(n.dotProduct(lightDirectional) > 0 ? delta : -delta);
		p0 = geoPoint.point.add(offset);
		dir = lightDirectional;
	}

	@Override
	public String toString() {
		return "Ray [p0=" + p0.toString() + ", dir=" + dir.toString() + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Ray other = (Ray) obj;

		return p0.equals(other.p0) && dir.equals(other.dir);
	}
	
	/*
	 * recieves double, and returns the central points plus the direction scaled to the double.
	 */
	public Point3D getPoint(double t)
	{
		return p0.add(dir.scale(t));
	
		
	}
	
	/**
	 * @param listPoints
	 * @return
	 * function that recieved Point3d list of points, and finds the closest point to the center, returning a nerestpoint
	 */
	public Point3D findClosestPoint(List<Point3D> listPoints)
	{
		double distance = Double.POSITIVE_INFINITY;
		Point3D nearestPoint = null;
		for(Point3D p : listPoints)
		{
			double dis = p.distance(p0);
			if(dis<distance)
			{
				distance = dis;
				nearestPoint = p;
			}
		}
		
		return nearestPoint;
	}
	
	/**
	 * 
	 * @param listPoints
	 * @return
	 * function that recieved Point3d list of points, and finds the closest point to the center, returning a closest point
	 */
	public GeoPoint findClosestGeoPoint(List<GeoPoint> listPoints)
	{
		GeoPoint result = null;
		if(listPoints == null)
			return null;
		double closestDistance = Double.MAX_VALUE;
		for(GeoPoint geo : listPoints)
		{
			double temp = geo.point.distance(p0);
			if(temp < closestDistance)
			{
				closestDistance = temp;
				result = geo;
			}
		}
		
		return result;
	}
	
	
	

}
