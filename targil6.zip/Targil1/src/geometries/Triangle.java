package geometries;

import java.util.ArrayList;
import java.util.List;

import geometries.Intersectable.GeoPoint;
import primitives.*;
import static primitives.Util.*;

import static primitives.Point3D.ZERO;

/**
 * triangle class represents two-dimensional triangle in 3D Cartesian coordinate
 * system, that is inherited from polygon
 * @author rajel and ruty
 *
 */
public class Triangle extends Polygon
{

	/**
	 * constructor for triangle based on 3 points
	 * @param a
	 * @param b
	 * @param c
	 */
	public Triangle(Point3D a, Point3D b, Point3D c)
	{
		super(a,b,c);
	}

//	@Override
//	public String toString() {
//		return super.toString();
//	}
//	
	
	//@Override
	//public Vector getNormal(Point3D point)
	//{
		//return super.getNormal(point);
	//}
	

	
//	@Override // to polygon
//	public List<GeoPoint> findGeoIntersections(Ray r)
//	{
//		List<GeoPoint> result = plane.findGeoIntersections(ray);
//		
//		 if (result == null) {
//	            return result;
//	        }
//		
//		for(int i = 0; i < result.size(); i++)
//		{
//			result.get(i).geometry = this;
//		}
//      
//        Point3D P0 = ray.getP0();
//        Vector v = ray.getDir();
//
//        Point3D P1 = vertices.get(1);
//        Point3D P2 = vertices.get(0);
//
//        Vector v1 = P1.subtract(P0).normalize();
//        Vector v2 = P2.subtract(P0).normalize();
//
//        double sign = alignZero(v.dotProduct(v1.crossProduct(v2)));
//
//        if (isZero(sign)) {
//            return null;
//        }
//
//        boolean positive = sign > 0;
//
//        //iterate through all vertices of the polygon
//        for (int i = vertices.size() - 1; i > 0; --i) {
//            v1 = v2;
//            v2 = vertices.get(i).subtract(P0);
//
//            sign = alignZero(v.dotProduct(v1.crossProduct(v2)));
//            if (isZero(sign)) {
//                return null;
//            }
//
//            if (positive != (sign > 0)) {
//                return null;
//            }
//        }
//
//        return result;
//}
		
	
	/**
	 * Returns cutting points of the body with the ray (if there are such points)
	 */
	public List<Point3D> findIntersections(Ray r) {

		// Check if there is at least one intersection point on the plane
		Plane plane = this.plane;
		double nv = plane.normal.dotProduct(r.getDir());
		if (isZero(nv))
			return null;
		if (plane.q0.equals(r.getP0())) // if the ray start at the center of the plane
			return null;
		double nQMinusP0 = plane.normal.dotProduct(plane.q0.subtract(r.getP0()));
		double tDistance = alignZero(nQMinusP0 / nv); // t = n*(Q-p0 )/ n*v
		if (tDistance <= 0)
			return null;

		Point3D P = r.getPoint(tDistance); // P = p0 + t* v

		Point3D p1 = this.vertices.get(0);
		Point3D p2 = this.vertices.get(1);
		Point3D p3 = this.vertices.get(2);

		if (p1.equals(r.getP0()) || p2.equals(r.getP0()) || p3.equals(r.getP0())) // if the point is on the vertex
			return null;

		Vector v1 = p1.subtract(r.getP0());
		Vector v2 = p2.subtract(r.getP0());
		Vector v3 = p3.subtract(r.getP0());

		Vector n1 = v1.crossProduct(v2);
		n1.normalize();

		Vector n2 = v2.crossProduct(v3);
		n2.normalize();

		Vector n3 = v3.crossProduct(v1);
		n3.normalize();

		// The point is inside if all V*Ni have the same sign

		double vn1 = alignZero(r.getDir().dotProduct(n1));
		double vn2 = alignZero(r.getDir().dotProduct(n2));
		double vn3 = alignZero(r.getDir().dotProduct(n3));

		if ((vn1 > 0 && vn2 > 0 && vn3 > 0) || (vn1 < 0 && vn2 < 0 && vn3 < 0)) // if the Point is inside the triangle
		{

			List<Point3D> listOfIntersections = new ArrayList<Point3D>();
			listOfIntersections.add(P);

			return listOfIntersections;
		}

		return null;
	}
	
	public List<GeoPoint> findGeoIntersections(Ray r) {

		// Check if there is at least one intersection point on the plane
		Plane plane = this.plane;
		double nv = plane.normal.dotProduct(r.getDir());
		if (isZero(nv))
			return null;
		if (plane.q0.equals(r.getP0())) // if the ray start at the center of the plane
			return null;
		double nQMinusP0 = plane.normal.dotProduct(plane.q0.subtract(r.getP0()));
		double tDistance = alignZero(nQMinusP0 / nv); // t = n*(Q-p0 )/ n*v
		if (tDistance <= 0)
			return null;

		Point3D P = r.getPoint(tDistance); // P = p0 + t* v

		Point3D p1 = this.vertices.get(0);
		Point3D p2 = this.vertices.get(1);
		Point3D p3 = this.vertices.get(2);

		if (p1.equals(r.getP0()) || p2.equals(r.getP0()) || p3.equals(r.getP0())) // if the point is on the vertex
			return null;


		Vector v1 = p1.subtract(r.getP0());
		Vector v2 = p2.subtract(r.getP0());
		Vector v3 = p3.subtract(r.getP0());

		Vector n1 = v1.crossProduct(v2);
		n1.normalize();

		Vector n2 = v2.crossProduct(v3);
		n2.normalize();

		Vector n3 = v3.crossProduct(v1);
		n3.normalize();

		// The point is inside if all V*Ni have the same sign

		double vn1 = alignZero(r.getDir().dotProduct(n1));
		double vn2 = alignZero(r.getDir().dotProduct(n2));
		double vn3 = alignZero(r.getDir().dotProduct(n3));
		//System.out.println(vn1 + " " + vn2 + " " + vn3);
		

		if ((vn1 > 0 && vn2 > 0 && vn3 > 0) || (vn1 < 0 && vn2 < 0 && vn3 < 0)) // if the Point is inside the triangle
		{

			List<GeoPoint> listOfIntersections = new ArrayList<GeoPoint>();
			listOfIntersections.add(new GeoPoint(this,P));
			return listOfIntersections;
		}

		return null;
	}
		
	}