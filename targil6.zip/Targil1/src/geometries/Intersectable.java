package geometries;

import primitives.*;

import java.util.List;
/**
 * interface to make all  others geometries and 3d shapes, connected to have intersections
 * @author rajel and ruth
 *
 */
import java.util.stream.Collectors;

/**
 * 
 * @author rajel and rajel
 * helper static class geopoint
 *
 */
public interface Intersectable 
{
	public static class GeoPoint {
	    public Geometry geometry;
	    public Point3D point;
	    
	    /**
	     * constructor of geoPoint
	     * @param g
	     * @param p
	     */
	    public GeoPoint(Geometry g, Point3D p)
	    {
	    	geometry = g;
	    	point = p;
	    }
	    
	    
	    @Override
	    public boolean equals(Object o)
	    {
	    	if(this == o) return true;
	    	if(o == null || this.getClass() != o.getClass() ) return false;
	    	GeoPoint geoPoint = (GeoPoint) o;
	    	return geometry.equals(geoPoint.geometry) && point.equals(geoPoint.point);
	    		
	    }
	    
	    
	}
	
	default List<Point3D> findIntersections(Ray ray) {
	    var geoList = findGeoIntersections(ray);
	    return geoList == null ? null
	                           : geoList.stream().map(gp -> gp.point).collect(Collectors.toList());
	}

  public List<GeoPoint> findGeoIntersections(Ray ray);
	
 

}
