package geometries;

import java.util.List;
import primitives.*;
import static primitives.Util.*;


/**
 * tube class represents two-dimensional tube in 3D Cartesian coordinate
 * system
 * @author rajel and ruty
 *
 */
public class Tube extends Geometry
{
	Ray axisRay;
	double radius;
	
	/**
	 * constructor of tube based on ray and double
	 * @param axisRay
	 * @param radius
	 */
	public Tube(Ray axisRay, double radius) {
		super();
		this.axisRay = axisRay;
		this.radius = radius;
	}
	

	/**
	 * 
	 * @return axisRay
	 */
	public Ray getAxisRay() {
		return axisRay;
	}

	/**
	 * 
	 * @return radius
	 */
	public double getRadius() {
		return radius;
	}

	@Override
	public String toString() {
		return "Tube [axisRay=" + axisRay.toString() + ", radius=" + radius + "]";
	}

	@Override
	public Vector getNormal(Point3D p) //p=000
	{
		Point3D P0 = axisRay.getP0();//010
		Vector v = axisRay.getDir();//001
		Vector P_P0 = p.subtract(P0);//010
		
		double t = v.dotProduct(P_P0);//0+0+0=0
		
		//if the distance is exactly perpendicular, so then its a regular normal with two points
		if(isZero(t))
		{
			return P_P0.normalize();
		}
		
		Point3D o = P0.add(P_P0.scale(t));//010+(010)=020
		if(o.equals(p)) 
		{
			throw new IllegalArgumentException("point p can't be on tube's axis");
		}
		
		return p.subtract(o).normalize();//000-020=0-20.normalize
		
		
		
		
		
		
	  
		
	}



	@Override
	public List<GeoPoint> findGeoIntersections(Ray ray) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
	

}
