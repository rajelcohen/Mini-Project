/**
 * 
 */
package elements;

import static primitives.Util.isZero;
import primitives.*;
import geometries.*;


/**
 * Class camera is the basic class representing a camera for 3D perspective. 
 * The class is based on Util, Geometries and Primitives. Controlling the accuracy and the shapes.
 * 
 * @author rajel and ruth
 *
 */
public class Camera 
{
    Point3D p0;
    Vector vUp;
	Vector vTo;
    Vector vRight;
	double width;
	double hight;
	double distance;
	
	
	/**
	 * 
	 * @return p0
	 */
	public Point3D getP0() {
		return p0;
	}
	
	/**
	 * 
	 * @return vUp
	 */
	public Vector getvUp() {
		return vUp;
	}
	
	/**
	 * 
	 * @return vTo
	 */
	public Vector getvTo() {
		return vTo;
	}
	
	/**
	 * 
	 * @return vRright
	 */
	public Vector getvRight() {
		return vRight;
	}
	
	/**
	 * 
	 * @return width
	 */
	public double getWidth() {
		return width;
	}
	
	/**
	 * 
	 * @return hight
	 */
	public double getHight() {
		return hight;
	}
	
	/**
	 * 
	 * @return distance
	 */
	public double getDistance() {
		return distance;
	}
	
	
	/**
	 * function for creation oc camera, recieves point vector to and vector up, creates vector right.
	 * @param o
	 * @param to
	 * @param up
	 */
	public Camera(Point3D o, Vector to, Vector up)
	{
		if(!isZero(up.dotProduct(to)))
		{
			throw new IllegalArgumentException("vTo and vUp are not orthogonal");	
		}
		
		p0 = o;
		vTo = to.normalize();
		vUp = up.normalize();
		
		
		vRight = vTo.crossProduct(vUp);
		
	}
	
	/**
	 * creation to set view plane, recieves width and hight
	 * @param w
	 * @param h
	 * @return
	 */
	public Camera setViewPlaneSize(double w, double h)
	{
		if(w == 0 || h == 0)
		{
			throw new IllegalArgumentException("the width or hight of the veiw plane can't be 0");	
		}
		width = w;
		hight = h;
		return this;
		
	} 
	
	/**
	 * function to set distance, gets distance and returns the camera
	 * @param d 
	 * @return
	 */
	public Camera setDistance(double d)
	{
		distance = d;
		return this;
	}
	
	/**
	 * function to calculate the ray that would pass through spesific pixel in view plane of this camera, returns the ray.
	 * @param nX
	 * @param nY
	 * @param j
	 * @param i
	 * @return
	 */
	public Ray constructRayThroughPixel(int nX, int nY, int j, int i)
	{
		//image center
		Point3D Pc = p0.add(vTo.scale(distance));
		
		//ratio
		double Ry = hight/nY;
		double Rx = width/nX;
		
		//pixel center
		Point3D Pij = Pc;
		double Yi = -(i - (nY - 1)/2d)*Ry;
		double Xj = (j - (nX -1)/2d)*Rx;
		
		if(!isZero(Xj))
		{
			Pij = Pij.add(vRight.scale(Xj));			
		}
		
		if(!isZero(Yi))
		{
			Pij = Pij.add(vUp.scale(Yi));
		}
		
		Vector Vij = Pij.subtract(p0);
		
		return new Ray(p0,Vij.normalize());
			
	}

	
	
	

}
