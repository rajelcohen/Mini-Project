/**
 * 
 */
package elements;

import primitives.Color;
import primitives.Point3D;
import primitives.Vector;


import static primitives.Util.isZero;
import primitives.*;
import geometries.*;


import static primitives.Point3D.ZERO;
import static primitives.Util.alignZero;
import static primitives.Util.isZero;



/**
 * @author rajel
 *
 */
public class SpotLight extends PointLight 
{
	private Vector direction;
	

	public SpotLight(Color intensity, Point3D position, Vector d)
	{
		super(intensity, position);
		this.direction = d.normalized();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public Color getIntensity(Point3D p) 
	{
		 double dirl =  this.direction.dotProduct(getL(p));
		 double max = Math.max(0, dirl);
		 return super.getIntensity(p).scale(max);
	}
	
	
	
	 public SpotLight setKl(double _kL)
	 {
		 super.setkL(_kL);
		 return this;
	 }
	 
	 public SpotLight setKq(double _Kq)
	 {
		 super.setkQ(_Kq);
		 return this;
	 }
	

}
