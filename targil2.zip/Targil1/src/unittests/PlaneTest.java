/**
 * 
 */
package unittests;
import primitives.*;
import geometries.Plane;

import static org.junit.Assert.*;

import org.junit.Test;



/**
 * @author rajel and ruth
 *  * Unit tests for Geometries.Plane class
 *
 */
public class PlaneTest
{

	/**
	 * Test method for {@link geometries.Plane#getNormal(primitives.Point3D)}.
	 */
	@Test
	public void testGetNormalPoint3D() 
	{
		
		  Point3D p1 = new Point3D(1, 1, 1);
	      Point3D p2 = new Point3D(3, 3, 2);
	      Point3D p3 = new Point3D(6, 6, 6);
	      Plane pl = new Plane(p1, p2, p3);
	      Vector n = pl.getNormal();
	      Vector s = new Vector(5, -5, 0);
	      s.normalize();
	      assertEquals(s, n);	
		
		
	}

}
