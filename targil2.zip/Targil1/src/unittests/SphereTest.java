/**
 * 
 */
package unittests;

import static org.junit.Assert.*;

import org.junit.Test;

import geometries.Sphere;
import primitives.Point3D;
import primitives.Vector;

/**
 * @author rajel and rut
 * * Unit tests for primitives.Shpere class
 *
 */
public class SphereTest {

	/**
	 * Test method for {@link geometries.Sphere#getNormal(primitives.Point3D)}.
	 */
	@Test
	public void testGetNormal() 
	{

        Sphere sp = new Sphere(new Point3D(0, 0, 1),1);
        Vector v1 = new Vector(0, 0, 1);
        Vector v2 = sp.getNormal(new Point3D(0, 0, 2));
        assertEquals( "ERROR: wrong normal",v1, v2);
	}

}
