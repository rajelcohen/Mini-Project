package geometries;

import java.util.List;
import primitives.*;
import static primitives.Util.*;

/**
 * sphere class represents two-dimensional shpere in 3D Cartesian coordinate
 * system
 * 
 * @author rajel and ruty
 *
 */
public class Sphere implements Geometry
{
	 final Point3D center;
	 final double radius;
	 
	 /**
	  * sphere constuctor based on point3d and radius
	  * @param center
	  * @param radius
	  */
	public Sphere(Point3D center, double radius) {
		super();
		this.center = center;
		this.radius = radius;
	}
	
	/**
	 * 
	 * @return center
	 */
	public Point3D getCenter() {
		return center;
	}
	
	/**
	 * 
	 * @return radius
	 */
	public double getRadius() {
		return radius;
	}
	 
	@Override
	public String toString() {
		return "Sphere [center=" + center.toString() + ", radius=" + radius + "]";
	}
	@Override
	public Vector getNormal(Point3D p) 
	{
		Vector v = p.subtract(center);
		return v.normalize();
		
	}
	
	

}
