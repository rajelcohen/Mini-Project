package geometries;

import java.util.List;
import primitives.*;
import static primitives.Util.*;
/**
 *  geometry class represents inteface all geometries in system.
 * @author rajel and ruty
 *
 */
public interface Geometry
{
	/**
	 * Normalization function acording to the class
	 * @param p
	 * @return
	 */
	public abstract Vector getNormal(Point3D p);

	
}
