package geometries;

import java.util.List;
import primitives.*;
import static primitives.Util.*;


/**
 * triangle class represents two-dimensional triangle in 3D Cartesian coordinate
 * system, that is inherited from polygon
 * @author rajel and ruty
 *
 */
public class Triangle extends Polygon
{

	/**
	 * constructor for triangle based on 3 points
	 * @param a
	 * @param b
	 * @param c
	 */
	public Triangle(Point3D a, Point3D b, Point3D c)
	{
		super(a,b,c);
	}

	@Override
	public String toString() {
		return super.toString();
	}
	
	
	//@Override
	//public Vector getNormal(Point3D point)
	//{
		//return super.getNormal(point);
	//}
	
	
	
	
}



